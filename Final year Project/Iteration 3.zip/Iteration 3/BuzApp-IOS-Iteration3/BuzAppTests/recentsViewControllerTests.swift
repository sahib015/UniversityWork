//
//  recentsViewControllerTests.swift
//  BuzAppTests
//
//  Created by Sahib Jabbal on 10/12/2017.
//  Copyright © 2017 University of Kent. All rights reserved.
//

import XCTest
@testable import BuzApp

var recentsSessionUnderTest: URLSession!

class recentsViewControllerTests: XCTestCase {
    
    override func setUp() {
        recentsSessionUnderTest =  URLSession(configuration: URLSessionConfiguration.default)
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        recentsSessionUnderTest = nil
        super.tearDown()
    }
    
    func testGetRecentStops(){
        // setting bus stop variables to test with its lattitude and longitude
        let recStop = ["Parkwood"]
        let recLat = [51.2980586]
        let recLon = [1.0579833]
        
        for i in 0...recStop.count-1 {
            // url to get the favourite stop from the favStop array
            let getRecStopUrl = URL(string: "https://transportapi.com/v3/uk/bus/stop/\(recStop[i])/live.json?app_id=a8fbdc15&app_key=b3d5f933e236d4c2572657618ba78394lat=\(recLat[i])&lon=\(recLon[i])")
            
            
            // what to expect when successful
            let successful = expectation(description: "Status code: 200")
            
            // when
            let dataTask = recentsSessionUnderTest.dataTask(with: getRecStopUrl!) { data, response, error in
                // then
                if let error = error {
                    XCTFail("Error: \(error.localizedDescription)")
                    return
                } else if let statusCode = (response as? HTTPURLResponse)?.statusCode {
                    if statusCode == 200 {
                        // 2
                        successful.fulfill()
                    } else {
                        XCTFail("Status code: \(statusCode)")
                    }
                }
            }
            dataTask.resume()
            waitForExpectations(timeout: 15, handler: nil)
        }
    
    }
    
    func testGetRecentDirection(){
     
        // assign a  recent stop atcocode
        let recStopAtcode = "2400A050300A"
        
        let limit = 5 // setting the limit
        
        // url for geting the direction to the bus stop
        let getRecDirectionUrl = URL(string: "https://transportapi.com/v3/uk/bus/stop/\(recStopAtcode)/live.json?app_id=a8fbdc15&app_key=b3d5f933e236d4c2572657618ba78394&group=no&limit=\(limit)&nextbuses=yes")
        
        // what to expect when successful
        let successful = expectation(description: "Status code: 200")
        
        // when
        let dataTask = recentsSessionUnderTest.dataTask(with: getRecDirectionUrl!) { data, response, error in
            // then
            if let error = error {
                XCTFail("Error: \(error.localizedDescription)")
                return
            } else if let statusCode = (response as? HTTPURLResponse)?.statusCode {
                if statusCode == 200 {
                    // 2
                    successful.fulfill()
                } else {
                    XCTFail("Status code: \(statusCode)")
                }
            }
        }
        dataTask.resume()
        waitForExpectations(timeout: 15, handler: nil)
        
    }
        
   
}
