//
//  Journey Planner Test.swift
//  BuzAppTests
//
//  Created by Marc Jean-Pierre on 23/03/2018.
//  Copyright © 2018 University of Kent. All rights reserved.
//

import UIKit
import XCTest
@testable import BuzApp


var journeySessionUnderTest: URLSession!
class Journey_Planner_Test: XCTestCase {
    
    override func setUp() {
        super.setUp()
        journeySessionUnderTest = URLSession(configuration: URLSessionConfiguration.default)
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        journeySessionUnderTest = nil
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testGetLocation(){
        let location = "Keynes"
        let urlString = URL(string: "https://transportapi.com/v3/uk/places.json?app_id=a8fbdc15&app_key=b3d5f933e236d4c2572657618ba78394&query=\(location)&type=bus_stop,postcode,region,street,poi")

        let successful = expectation(description: "Status code: 200")
        
        let dataTask = journeySessionUnderTest.dataTask(with: urlString!) { data, response, error in
            // then
            if let error = error {
                XCTFail("Error: \(error.localizedDescription)")
                return
            } else if let statusCode = (response as? HTTPURLResponse)?.statusCode {
                if statusCode == 200 {
                    // 2
                    successful.fulfill()
                } else {
                    XCTFail("Status code: \(statusCode)")
                }
            }
        }
        dataTask.resume()
        waitForExpectations(timeout: 15, handler: nil)
    }
    
    func testGetDirection(){
        let fromPlaceLat = 51.2945
        let fromPlaceLong = 1.06606
        let toPlaceLat = 51.29905
        let toPlaceLong = 1.07161
        
        let urlString = URL(string: "http://maps.apple.com/maps?saddr=\(fromPlaceLat),\(fromPlaceLong)&daddr=\(toPlaceLat),\(toPlaceLong)&dirflg=r")
        
        let successful = expectation(description: "Status code: 200")
        
        let dataTask = journeySessionUnderTest.dataTask(with: urlString!) { data, response, error in
            // then
            if let error = error {
                XCTFail("Error: \(error.localizedDescription)")
                return
            } else if let statusCode = (response as? HTTPURLResponse)?.statusCode {
                if statusCode == 200 {
                    // 2
                    successful.fulfill()
                } else {
                    XCTFail("Status code: \(statusCode)")
                }
            }
        }
        dataTask.resume()
        waitForExpectations(timeout: 15, handler: nil)
    }

}
