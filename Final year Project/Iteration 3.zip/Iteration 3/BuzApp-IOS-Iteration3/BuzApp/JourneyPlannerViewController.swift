//
//  JourneyPlannerViewController.swift
//  BuzApp
//
//  Created by Marc Jean-Pierre on 29/01/2018.
//  Copyright © 2018 University of Kent. All rights reserved.
//

import UIKit
import MapKit

class JourneyPlannerViewController: UIViewController, UISearchBarDelegate, UITableViewDelegate, UITableViewDataSource {
    let kentColor = UIColor(red: 9/255, green: 53/255, blue: 90/255, alpha: 1)
    @IBOutlet weak var searchBar1: UISearchBar!
    @IBOutlet weak var searchBar2: UISearchBar!
    @IBOutlet weak var lblEventTitleAndLocation: UILabel!
    private var member = [JourneyPlanner]()
    @IBOutlet weak var TableView2: UITableView!
    @IBOutlet weak var TableView1: UITableView!
    var place1 : [String] = []
    var place2 : [String] = []
    var check = 0
    var fromSearch = String()
    var toSearch = String()
    var stops: [String] = []
    var location = String()
    var location2 = String()
    var cellint = 0
    var fromPlaceLong = Double()
    var fromPlaceLat = Double()
    var toPlaceLong = Double()
    var toPlaceLat = Double()
    var eventLocation:String = String()
    var eventTime:Date = Date()
    var dateHolder = String()
    var timeHolder = String()

    //Method is for when the search button is clicked, gets the input from the user and passes it to the call to the API once enter is clicked
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        if (searchBar.tag == 1)
        {
            let keywords = searchBar.text
            location = (keywords?.replacingOccurrences(of: " ", with: "_"))!
            downloadJSON(string: location)
            
        } else if
        (searchBar.tag == 2)
        {
            let keywords2 = searchBar.text
            location2 = (keywords2?.replacingOccurrences(of: " ", with: "_"))!
             downloadJSON2(string: location2)
            
        }
        self.view.endEditing(true)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        TableView1.delegate = self
        TableView1.dataSource = self
        TableView2.delegate = self
        TableView2.dataSource = self
        self.navigationController?.navigationBar.barTintColor = kentColor
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName:UIColor.white]
        self.navigationController?.navigationBar.tintColor = UIColor.white
    }
    
    override func viewDidAppear(_ animated:Bool){
        super.viewDidAppear(animated)
        if eventLocation == ""{
            searchBar2.placeholder = "provide destination" // allows user to  input destination
        } else{
            searchBar2.text = eventLocation // adding event Location to the destination search bar
        }
        // checks if the event location variable contains the following and changes the text in the destination search bar to allow the API to find the appropriate bus stop
        if(eventLocation == "CFSR"){
            searchBar2.text = "CT27NB"
        }
        else if(eventLocation == "CEPC1" || eventLocation == "CEPC2" || eventLocation == "CESR1" || eventLocation == "CESR2"){
            searchBar2.text = "CT27NF"
        }
        else if(eventLocation == "CNWsr1" || eventLocation == "CNWsr2" || eventLocation == "CNWsr3" || eventLocation == "CNWsr4" || eventLocation == "CNWsr5" || eventLocation == "CNWsr6" || eventLocation == "CNWsr7" || eventLocation == "CNWsr8" || eventLocation == "CNWsr9" || eventLocation == "CNWsr10" || eventLocation == "CNWsr11" || eventLocation == "CNWsr12" || eventLocation == "MMLab1" || eventLocation == "MMLab2"){
            searchBar2.text = "CT27NF"
        }
        
        else if(eventLocation == "CC02" || eventLocation == "CC03" || eventLocation == "COLT2" || eventLocation == "COLT3"){
            searchBar2.text = "CT27NF"
        }
        
       else if(eventLocation == "DLT1" || eventLocation == "DLT2" || eventLocation == "DLT3" || eventLocation == "DS1" ||  eventLocation == "DS2" || eventLocation == "DS10" || eventLocation == "DS11" || eventLocation == "DS12" || eventLocation == "DS14" || eventLocation == "DS7" || eventLocation == "DS8" || eventLocation == "DS9"){
            searchBar2.text = "CT27NY"
        }
        else if(eventLocation == "EBC16" || eventLocation == "EBC17" || eventLocation == "ECT1" || eventLocation == "ELT2" || eventLocation == "ES1" || eventLocation == "ES2" || eventLocation == "ES3" || eventLocation == "EXSR1" || eventLocation == "EXSR2" || eventLocation == "EXSR3" || eventLocation == "ES1"){
            searchBar2.text = "CT27NS"
        }
     
       else if(eventLocation == "GLT1" || eventLocation == "GLT2" || eventLocation == "GLT3" || eventLocation == "GS1" || eventLocation == "GS2" || eventLocation == "GS3" || eventLocation == "GS4" || eventLocation == "GS6" || eventLocation == "GS7" || eventLocation == "GS8" || eventLocation == "Lupino SR"){
            searchBar2.text = "CT27NZ"
        }
        
        else if(eventLocation == "I316" || eventLocation == "ILT" || eventLocation == "EPS G52" || eventLocation == "PS Lab1" || eventLocation == "PS Lab2" || eventLocation == "PS Lab3" || eventLocation == "PS Lab4" || eventLocation == "PS Project room" || eventLocation == "PS Research Lab" || eventLocation == "PS110"){
            searchBar2.text = "CT27NH"
        }
        
        else if(eventLocation == "Jarman Stud1" || eventLocation == "Jarman Stud2" || eventLocation == "Jarman Stud3" || eventLocation == "Jarman Stud4" || eventLocation == "Jarman Stud5" || eventLocation == "Jarman Stud6" || eventLocation == "Jarman Stud7" || eventLocation == "Jarman Stud8" || eventLocation == "Jarman Stud9"  || eventLocation == "Jarman Stud10"  || eventLocation == "Jarman Stud12" || eventLocation == "Jarman Stud13" || eventLocation == "Jarman Stud14" || eventLocation == "Jarman Stud15" || eventLocation == "Jarman Stud16"  || eventLocation == "Jarman Stud17"){
            searchBar2.text = "CT27UG"
        }
       else if(eventLocation == "Eng Lab Blue" || eventLocation == "Eng Lab Orange"  || eventLocation == "JCS1" || eventLocation == "JCS2"  || eventLocation == "JCS3" || eventLocation == "JCS4" || eventLocation == "JCS5"  || eventLocation == "JLT" || eventLocation == "JS1"){
            searchBar2.text = "CT27NT"
        }
        else if(eventLocation == "KBSX1" || eventLocation == "KBSX2" || eventLocation == "KBSX3" || eventLocation == "KBSX4" || eventLocation == "KBSXPC"){
            searchBar2.text = "CT27PE"
        }
        else if(eventLocation == "Keynes SR L1.9" || eventLocation == "KLT1" || eventLocation == "KLT2" || eventLocation == "KLT3" || eventLocation == "KLT4" || eventLocation == "KLT5" || eventLocation == "KLT6" || eventLocation == "KS1" || eventLocation == "KS2" || eventLocation == "KS3" || eventLocation == "KS4" || eventLocation == "KS5" || eventLocation == "KS6" || eventLocation == "KS7" || eventLocation == "KS11" || eventLocation == "KS12" || eventLocation == "KS13" || eventLocation == "KS14" || eventLocation == "KS15" || eventLocation == "KS16" || eventLocation == "KS17" || eventLocation == "KS20" || eventLocation == "KS21" || eventLocation == "KS23" || eventLocation == "KS24" || eventLocation == "KS26" || eventLocation == "KSA1(42)" || eventLocation == "Psyc Comp Rm" || eventLocation == "Psyc Conf Rm" || eventLocation == "Psyc Lab E3" || eventLocation == "Psyc_Comp_Maste" ){
            searchBar2.text = "CT27NP"
        }
        else if ( eventLocation == "BA Model-making" || eventLocation == "Drama Workshop" || eventLocation == "Ethnobio Lab " || eventLocation == "Hugh Brody Room" || eventLocation == "Mar 113" || eventLocation == "Mar 116" || eventLocation == "Mar 119" || eventLocation == "Mar Crit Rm" || eventLocation == "Mar MA Comp Lab" || eventLocation == "Mar PC Lab" || eventLocation == "Mar Studio A" || eventLocation == "Mar Studio B" || eventLocation == "Mar Studio C" || eventLocation == "Mar Workshop" || eventLocation == "MarLT1" || eventLocation == "MarLT2" || eventLocation == "Stirling Lib" || eventLocation == "Swingland Room"){
            searchBar2.text = "CT27NR"
        }
        else if(eventLocation == "R.Cl.15" || eventLocation == "R.Cl.16" || eventLocation == "R.Cl.17" || eventLocation == "R.Cl.19" || eventLocation == "R.Cl.20" || eventLocation == "R.Cl.21" || eventLocation == "R.RogersRm" || eventLocation == "RLT1" || eventLocation == "RLT2" || eventLocation == "RS4" || eventLocation == "RS7" || eventLocation == "RX11" || eventLocation == "RX12" ){
            searchBar2.text = "CT27NX"
        }
        else if(eventLocation == "SIBLT1(170)" || eventLocation == "SIBLT2" || eventLocation == "SIBLT3" || eventLocation == "SIBPC1" || eventLocation == "SIBPC2" || eventLocation == "SIBSR1" || eventLocation == "SIBSR2" || eventLocation == "SIBSR3" || eventLocation == "SIBSR4" || eventLocation == "SIBSR5" || eventLocation == "SIBSR6" ){
            searchBar2.text = "CT27PE"
        }
        else if(eventLocation == "Bio Res Labs" || eventLocation == "Biol Lab 1" || eventLocation == "Biol Lab 2" || eventLocation == "Biol Lab 3" || eventLocation == "SLT1" || eventLocation == "SLT2" ){
            searchBar2.text = "CT27NJ"
        }
        else if(eventLocation == "Lib Training Rm" || eventLocation == "TLT" || eventLocation == "TSR1" || eventLocation == "TSR2" || eventLocation == "TSR3" || eventLocation == "TSR4" || eventLocation == "TSR5" || eventLocation == "TSR6" || eventLocation == "TSR7" || eventLocation == "TSR8" ){
            searchBar2.text = "CT27NU"
        }
        else if(eventLocation == "CGUS(24)" || eventLocation == "Cinema"){
            searchBar2.text = "CT27NB"
        }
        else if(eventLocation == "UELT Sem Room"){
            searchBar2.text = "CT27NQ"
        }
        else if(eventLocation == "W1-SR1" || eventLocation == "W1-SR2" || eventLocation == "W1-SR3" || eventLocation == "W1-SR4" || eventLocation == "W1-SR5" || eventLocation == "W1-SR6" || eventLocation == "W-LT" ){
            searchBar2.text = "CT27BQ"
        }
        else if(eventLocation == "STA_OFF"){
            searchBar2.text = "University of Kent"
        }
        else{
            searchBar2.text = eventLocation
        }
        
    }
    
    // Method to get the number of cells needed for the table view, based on number of search results from users input
   public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        
        if (tableView.tag == 1)
        {
        return member.count
    } else if
        (tableView.tag == 2)
        {
            return member.count
        }
        else{
            return 0
    }
    }
    
    //Populates the label in the table view with the name of the bus stop or postcode for the user to select
 func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as? JourneyPlannerCell else {
        return UITableViewCell()
    }
        if (tableView.tag == 1)
        {
        cell.nameLbl.text = member[indexPath.row].name
        return cell
    } else if
        (tableView.tag == 2)
        {
            cell.nameLbl2?.text = member[indexPath.row].name
            return cell
        
        }
    return cell
        }
    
    //Method for when the cell is selected. Populates the search bar with the item that has been selected and saves the longitude and latititude of that item
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        cellint = indexPath.row
        var cell = tableView.dequeueReusableCell(withIdentifier: "Cell")! as? JourneyPlannerCell
        if (tableView.tag == 1)
        {
            cell?.nameLbl.text = member[cellint].name
            searchBar1.text = cell?.nameLbl.text
            print(member[cellint].longitude)
            print(member[cellint].latitude)
            fromPlaceLat = member[cellint].latitude!
            fromPlaceLong = member[cellint].longitude!
        } else if
        (tableView.tag == 2)
        {
            cell?.nameLbl2.text = member[cellint].name
            searchBar2.text = cell?.nameLbl2.text
            print(member[cellint].longitude)
            print(member[cellint].latitude)
            toPlaceLat = member[cellint].latitude!
            toPlaceLong = member[cellint].longitude!
        }
    }
    

    //Method used to parse the JSON data from the API call
    func downloadJSON(string: String){
        let urlString = "https://transportapi.com/v3/uk/places.json?app_id=a8fbdc15&app_key=b3d5f933e236d4c2572657618ba78394&query=\(location)&type=bus_stop,postcode,region,street,poi"
        
        let url = URL(string: urlString)
        
        guard let downloadURL = url else { return }
        URLSession.shared.dataTask(with: downloadURL) { (data, urlResponse, error) in
            guard let data = data, error == nil, urlResponse != nil else{
                print("Something is wrong")
                return
            }
             print("downloaded")
            do{
                let decoder = JSONDecoder()
                let downloadedMember = try decoder.decode(Member.self, from: data)
                self.member = downloadedMember.member
                DispatchQueue.main.async {
                    self.TableView1.reloadData()
                }
                
                print(downloadedMember.member[0].name)
            } catch{
                print("Something wrong after downloading")
                
            }
        }.resume()
    }
    
    //Method used to parse the JSON data from the API call
    func downloadJSON2(string: String){
        let urlString = "https://transportapi.com/v3/uk/places.json?app_id=a8fbdc15&app_key=b3d5f933e236d4c2572657618ba78394&query=\(location2)&type=bus_stop,postcode,region,street,poi"
        
        let url = URL(string: urlString)
        
        guard let downloadURL = url else { return }
        URLSession.shared.dataTask(with: downloadURL) { (data, urlResponse, error) in
            guard let data = data, error == nil, urlResponse != nil else{
                print("Something is wrong")
                return
            }
            print("downloaded")
            do{
                let decoder = JSONDecoder()
                let downloadedMember = try decoder.decode(Member.self, from: data)
                self.member = downloadedMember.member
                DispatchQueue.main.async {
                    self.TableView2.reloadData()
                }
                
                print(downloadedMember.member[0].name)
            } catch{
                print("Something wrong after downloading")
                
            }
            }.resume()
    }
    
    //Method used to get rid of the keyboard once the user presses somewhere else on the screen
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        searchBar1.endEditing(true)
        searchBar2.endEditing(true)
    }
    
// This method is used to send the locations that the user has selected to Apple Maps to return the route that the user needs to take
    @IBAction func getDirections(_ sender: Any) {
        
        let url = "http://maps.apple.com/maps?saddr=\(fromPlaceLat),\(fromPlaceLong)&daddr=\(toPlaceLat),\(toPlaceLong)&dirflg=r"
        if let myUrl = URL(string: "\(url)") {
            UIApplication.shared.open(myUrl, options: [:], completionHandler: nil)
        }
    }
    
}




