//
//  JourneyPlanner.swift
//  BuzApp
//
//  Created by Marc Jean-Pierre on 06/02/2018.
//  Copyright © 2018 University of Kent. All rights reserved.
//

import UIKit

class Member: Codable{
    let member: [JourneyPlanner]
    
    init(member: [JourneyPlanner]){
        self.member = member
    }
}

// This sets up the structure for the API data that is needed for the journey planner
class JourneyPlanner: Codable{
    
    let type: String?
    let name: String?
    let description: String?
    let latitude : Double?
    let longitude : Double?
    
    
    init(type: String, name:String, description:String, latitude:Double, longitude:Double){
        self.type = type
        self.name = name
        self.description = description
        self.latitude = latitude
        self.longitude = longitude
        
    }
    
}



