//
//  BusStopViewController.swift
//  BuzApp
//
//  Created by James McIntyre on 20/10/2016.
//  Adjusted and changes made by Sahib Jabbal and Marc Jean-Pierre
//  Copyright © 2016 University of Kent. All rights reserved.
//

import UIKit
import MapKit

class BusStopViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, MKMapViewDelegate, CLLocationManagerDelegate {
    
    let kentColor = UIColor(red: 9/255, green: 53/255, blue: 90/255, alpha: 1)
    var busNames: [String] = []
    var busBestTimes: [String] = []
    var busBestTimes2: [String] = []
    var busDirections: [String] = []
    var busDirectionCodes: [String] = []
    var busLine: [String] = []
    var busAimedTimes: [String] = []
    var busDates: [String] = []
    var busOperator: [String] = []
    let regionRadius: CLLocationDistance = 400
    var busStopName = String()
    var busAtcocode = String()
    var busLocality = String()
    var busLong = Double()
    var busLat = Double()
    var cellint = 0
    var refreshControl: UIRefreshControl!
    var userlat = Double()
    var userlon = Double()
    var locationManager = CLLocationManager()

    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addToFavourites: UIBarButtonItem!
    
    // boolean for checking if add to favourite button is selected or not
    var isSelected: Bool = false
    
    //images
    let favSelected:UIImage = UIImage(named:"favouriteSelected.png")!
    let favNotSelected:UIImage = UIImage(named:"favouriteNotSelected.png")!
    // cell reuse id (cells that scroll out of view can be reused)
    let cellReuseIdentifier = "cell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.barTintColor = kentColor
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName:UIColor.white]
        self.navigationController?.navigationBar.tintColor = UIColor.white

        self.navigationItem.title = busStopName
        
        busMap.delegate = self
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
        
        busMap.showsUserLocation = true
        
        getStops()

        // Register the table view cell class and its reuse id
        self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: cellReuseIdentifier)
        
        
        _ = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.enterData), userInfo: nil, repeats: true);
        
        _ = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(self.drawline), userInfo: nil, repeats: false);
        
        
        
        // This view controller itself will provide the delegate methods and row data for the table view.
        tableView.delegate = self
        tableView.dataSource = self
        
        refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(self.refresh), for: UIControlEvents.valueChanged)
        tableView.addSubview(refreshControl)
        
        // checks if the bus stop is in favourites.
        if(favStopNames.contains(busStopName)){
            
            addToFavourites.setBackgroundImage(favSelected, for: .normal, barMetrics: .default)
            !isSelected // changes value of is selected to true
        }
        else{
            
            addToFavourites.setBackgroundImage(favNotSelected, for: .normal, barMetrics: .default)
            isSelected = false
        }
    }
    
    //Empty list while refreshing and reload new data
    func refresh(sender:AnyObject) {
        self.busNames.removeAll()
        self.busBestTimes.removeAll()
        self.busDirections.removeAll()
        self.tableView.reloadData()
        getStops()
        refreshControl.endRefreshing()
    }
    
    func drawline(){
        let sourceLocation = CLLocationCoordinate2D(latitude: userlat, longitude: userlon)
        let destinationLocation = CLLocationCoordinate2D(latitude: busLat, longitude: busLong)
        
        
        let sourcePlacemark = MKPlacemark(coordinate: sourceLocation, addressDictionary: nil)
        let destinationPlacemark = MKPlacemark(coordinate: destinationLocation, addressDictionary: nil)
        
        // MKItems used for routing
        let sourceMapItem = MKMapItem(placemark: sourcePlacemark)
        let destinationMapItem = MKMapItem(placemark: destinationPlacemark)
        
        // Annotations to show the names of stops
        let sourceAnnotation = MKPointAnnotation()
        sourceAnnotation.title = "User Starting Position"
        
        if let location = sourcePlacemark.location {
            sourceAnnotation.coordinate = location.coordinate
        }
        
        
        let destinationAnnotation = MKPointAnnotation()
        destinationAnnotation.title = busStopName
        
        if let location = destinationPlacemark.location {
            destinationAnnotation.coordinate = location.coordinate
        }
        
        // show annotations
        self.busMap.showAnnotations([destinationAnnotation], animated: true )
        
        print(userlon)
        print(userlat)
        
        // compute route based on mk data
        let directionRequest = MKDirectionsRequest()
        directionRequest.source = sourceMapItem
        directionRequest.destination = destinationMapItem
        directionRequest.transportType = .walking
        
        // Calculate the direction
        let directions = MKDirections(request: directionRequest)
        
        // draw the line
        directions.calculate {
            (response, error) -> Void in
            
            guard let response = response else {
                if let error = error {
                    print("Error: \(error)")
                }
                
                return
            }
            
            let route = response.routes[0]
            self.busMap.add((route.polyline), level: MKOverlayLevel.aboveRoads)
            
            let rect = route.polyline.boundingMapRect
            self.busMap.setRegion(MKCoordinateRegionForMapRect(rect), animated: true)
        }
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = kentColor
        renderer.lineWidth = 3.0
        renderer.lineDashPattern = [2,5]
        renderer.alpha = 0.8;

        return renderer
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBOutlet weak var busMap: MKMapView!
    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,
                                                                  regionRadius * 4.0, regionRadius * 4.0)
        busMap.setRegion(coordinateRegion, animated: true)
    }
    
    // Enter the information loaded from the API into the Labels
    func enterData(){
        self.tableView.reloadData()
    }
    
    //get user long and lat
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        
        userlat = locValue.latitude
        userlon = locValue.longitude
        
    }
    
 
    
    // number of rows in table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.busBestTimes.count
    }
    
    // create a cell for each table view row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //variable type is inferred
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell")! as UITableViewCell
        
        cell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")

        // we know that cell is not empty now so we use ! to force unwrapping but you could also define cell as
        // let cell = (tableView.dequeue... as? UITableViewCell) ?? UITableViewCell(style: ...)
        var imageName = "bus.png"

        let bestTimeBusHours = self.busBestTimes2[indexPath.row].index(self.busBestTimes2[indexPath.row].startIndex, offsetBy: 2)
        let bestBusHour = self.busBestTimes2[indexPath.row].substring(to: bestTimeBusHours)
        let bestBusHoursToInt = Int(bestBusHour)
        let bestTimeBusMinutes = self.busBestTimes2[indexPath.row].index(self.busBestTimes2[indexPath.row].startIndex, offsetBy: 3)
        let bestBusMinutes = self.busBestTimes2[indexPath.row].substring(from: bestTimeBusMinutes)
        let bestBusMinutesToInt = Int(bestBusMinutes)
        let aimedTimeBusHours = self.busAimedTimes[indexPath.row].index(self.busAimedTimes[indexPath.row].startIndex, offsetBy: 2)
        let aimedBusHour = self.busAimedTimes[indexPath.row].substring(to: aimedTimeBusHours)
        let aimedBusHoursToInt = Int(aimedBusHour)
        let aimedTimeBusMinutes = self.busAimedTimes[indexPath.row].index(self.busAimedTimes[indexPath.row].startIndex, offsetBy: 3)
        let aimedBusMinutes = self.busAimedTimes[indexPath.row].substring(from: aimedTimeBusMinutes)
        let aimedBusMinutesToInt = Int(aimedBusMinutes)
        
        if ((bestBusHoursToInt! * 60)+bestBusMinutesToInt!) > ((aimedBusHoursToInt! * 60)+aimedBusMinutesToInt!){
        imageName = "late.png"
        }else {
        imageName = "bus.png"
        }
        
        let image = UIImage(named: imageName)
        cell.imageView!.image = image
        
        if busNames.count != 0{
            cell.textLabel?.text = "\(self.busNames[indexPath.row]): towards \(self.busDirections[indexPath.row])"
        }
        else{
            cell.textLabel?.text = "No bus information currently available"
        }
        
        if busDirections.count != 0 {
            if ((bestBusHoursToInt! * 60)+bestBusMinutesToInt!) > ((aimedBusHoursToInt! * 60)+aimedBusMinutesToInt!){
                cell.detailTextLabel?.text = "Late - Expected: \(self.busBestTimes[indexPath.row]) mins"
            }else {
                cell.detailTextLabel?.text = "Due: \(self.busBestTimes[indexPath.row]) mins"
            }
            
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.accessoryType = .disclosureIndicator
    }
    
    //method to run when table view cell is tapped
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        cellint = indexPath.row
        let indexPath = tableView.indexPathForSelectedRow;
        self .performSegue(withIdentifier: "showInfoSegue", sender: self)
        }
    
    func addToRecents()
    {
        
        
        // adds recent stop to recents
        recStopNames.append(busStopName)
        recStopAtco.append(busAtcocode)
        recStopLocality.append(busLocality)
        recStopLatitude.append(busLat)
        recStopLongitude.append(busLong)
        
        
        
        // stores the user defaults to the value  in recStopNames
        UserDefaults.standard.set(recStopNames, forKey: "myrecents")
        UserDefaults.standard.set(recStopAtco, forKey: "myrecentsAtco")
        UserDefaults.standard.set(recStopLocality, forKey: "myrecentsLocality")
        UserDefaults.standard.set(recStopLatitude, forKey: "myrecentsLatitude")
        UserDefaults.standard.set(recStopLongitude, forKey: "myrecentsLongitude")
        
        
        print("added to recents \(recStopNames)")
    }
    
    
    func getStops() {
        
        let limit = 5
        
        //URL string for bus stop with acto code
        let urlString = "https://transportapi.com/v3/uk/bus/stop/\(busAtcocode)/live.json?app_id=a8fbdc15&app_key=b3d5f933e236d4c2572657618ba78394&group=no&limit=\(limit)&nextbuses=yes"
        
        let url = URL(string: urlString)
        URLSession.shared.dataTask(with:url!, completionHandler: {(data, response, error) in
            if error != nil {
                print(error)
            } else {
                do {
                    
                    let parsedData = try JSONSerialization.jsonObject(with: data!, options: .allowFragments)
                    let dictionary = parsedData as? [String: AnyObject]

                    let dep = dictionary?["departures"] as? [String: AnyObject]   //! [NSObject: AnyObject]

                    if let arrDep = dep?["all"] as? [[String: AnyObject]] {
                        print(arrDep)
                        for index in 0...arrDep.count-1 {
                            let aObject = arrDep[index]
                            self.busBestTimes.append(aObject["best_departure_estimate"] as! String)
                            self.busBestTimes2.append(aObject["best_departure_estimate"] as! String)
                            self.busNames.append(aObject["line"] as! String)
                            self.busDirections.append(aObject["direction"] as! String)
                            self.busAimedTimes.append(aObject["aimed_departure_time"] as! String)
                            if (aObject["dir"] is NSNull) {
                                self.busDirectionCodes.append("noroute")
                            } else {
                                self.busDirectionCodes.append(aObject["dir"] as! String)
                            }
                            self.busDates.append(aObject["date"] as! String)
                            self.busOperator.append(aObject["operator"] as! String)
                            self.busLine.append(aObject["line_name"] as! String)
                        }
                        
                        let date = Date()
                        let calendar = Calendar.current
                        let hour = (calendar.component(.hour, from: date))
                        let minutes = calendar.component(.minute, from: date)
                        
                        for busses in 0 ... arrDep.count-1 {
                            
                            let startIndex = self.busBestTimes[busses].index(self.busBestTimes[busses].startIndex, offsetBy: 2)
                            let busHour = self.busBestTimes[busses].substring(to: startIndex)
                            let convertBusHoursToInt = Int(busHour)
                            let remainingHours = (convertBusHoursToInt! * 60 - hour * 60)
                            
                            let minutesIndex = self.busBestTimes[busses].index(self.busBestTimes[busses].startIndex, offsetBy: 3)
                            let busMinutes = self.busBestTimes[busses].substring(from: minutesIndex)
                            let convertBusMinutesToInt = Int(busMinutes)
                            var remainingMinutes = (remainingHours + convertBusMinutesToInt! - minutes)
                            if (remainingMinutes < -20) {
                            remainingMinutes = remainingMinutes + 1440
                            }
                            self.busBestTimes[busses] = String(remainingMinutes)
                            
                        }
                        //self.enterData()
                    }

                } catch let error as NSError {
                    print(error)
                }
            }
            
        }).resume()}
    
    //Once clicked, adds the stop to the users favourites
    @IBAction func addToFavourites(_ sender: Any) {
        // checks for any existing favourites
        if(favStopNames.contains(busStopName)){
            //delete from favourite list
           let favStopIndex = favStopNames.index(of: busStopName)
            let favStopAtcoIndex = favStopAtco.index(of: busAtcocode)
            let favStopLocalityIndex = favStopLocality.index(of: busLocality)
            let favStopLatIndex = favStopLatitude.index(of: busLat)
            let favStopLongIndex = favStopLongitude.index(of: busLong)
            
            favStopNames.remove(at: favStopIndex!)
            favStopAtco.remove(at: favStopAtcoIndex!)
            favStopLocality.remove(at:favStopLocalityIndex!)
            favStopLatitude.remove(at: favStopLatIndex!)
            favStopLongitude.remove(at: favStopLongIndex!)
            
            // stores the user defaults to the value  in favStopNames
            UserDefaults.standard.set(favStopNames, forKey: "myfavourites")
            UserDefaults.standard.set(favStopAtco, forKey: "myfavouritesAtco")
            UserDefaults.standard.set(favStopLocality, forKey: "myfavouritesLocality")
            UserDefaults.standard.set(favStopLatitude, forKey: "myfavouritesLatitude")
            UserDefaults.standard.set(favStopLongitude, forKey: "myfavouritesLongitude")
            
              addToFavourites.setBackgroundImage(favNotSelected, for: .normal, barMetrics: .default)
            // alerts the user the the favourite bus stop added
            let alertController = UIAlertController(title: "BuzzApp", message: "\(busStopName) removed from favourties", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
        
        else if(isSelected == false){
            
            // adds favourite stop to favourites
            favStopNames.append(busStopName)
            favStopAtco.append(busAtcocode)
            favStopLocality.append(busLocality)
            favStopLatitude.append(busLat)
            favStopLongitude.append(busLong)
            
            
            // stores the user defaults to the value  in favStopNames
            UserDefaults.standard.set(favStopNames, forKey: "myfavourites")
            UserDefaults.standard.set(favStopAtco, forKey: "myfavouritesAtco")
            UserDefaults.standard.set(favStopLocality, forKey: "myfavouritesLocality")
            UserDefaults.standard.set(favStopLatitude, forKey: "myfavouritesLatitude")
            UserDefaults.standard.set(favStopLongitude, forKey: "myfavouritesLongitude")
           
            // alerts the user the the favourite bus stop added
            let alertController = UIAlertController(title: "BuzzApp", message: "Successfully added \(busStopName) to favourties", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
            
            print("added to favourites \(favStopNames)")
            
            //changes state of button
            addToFavourites.setBackgroundImage(favSelected, for: .normal, barMetrics: .default)
          
        }
        
        

    }
   
    
   //Prepares the Bus Info View by sending the varibales to the class via a segue 
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "showInfoSegue"){
            let DestViewController : BusInfoViewController = segue.destination as! BusInfoViewController
            DestViewController.stopName = busStopName
            DestViewController.stopAtco = busAtcocode
            DestViewController.busLine = busLine[cellint]
            DestViewController.busOperator = busOperator[cellint]
            DestViewController.busAtcoCode = busAtcocode
            DestViewController.busBestTime = busBestTimes[cellint]
            DestViewController.busAimedTime = busAimedTimes[cellint]
            DestViewController.busDate = busDates[cellint]
            //DestViewController.busTime = busActualTimes[cellint]
            DestViewController.busDirectionCode = busDirectionCodes[cellint]
            print(cellint)
            print(busStopName)
        }
    }
    
    
}
