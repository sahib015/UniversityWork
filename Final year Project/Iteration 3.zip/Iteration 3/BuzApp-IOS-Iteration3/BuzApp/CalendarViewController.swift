//
//  CalendarViewController.swift
//  BuzApp
//
//  Created by Sahib Jabbal on 24/01/2018.
//  Copyright © 2018 University of Kent. All rights reserved.
//

import UIKit
import CoreLocation
import EventKit

class CalendarViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
  
    
     let kentColor = UIColor(red: 9/255, green: 53/255, blue: 90/255, alpha: 1)
    let eventStore:EKEventStore = EKEventStore()
    let date = Date()
    let currentCalendar = Calendar.current
    var allEvents:[EKEvent]=[]
     var check = 0
     var cellint = 0
    var refreshControl: UIRefreshControl!
    let geoCoder = CLGeocoder()
    // cell reuse id (cells that scroll out of view can be reused)
    let cellReuseIdentifier = "cell"
    var eventLocation:String = ""
 
    var eventTime:Date = Date()
    var calendars:[EKCalendar]=[]
  
    
    @IBOutlet weak var calenderTableView: UITableView!
    @IBOutlet weak var lblNoEvents: UILabel!
    

    override func viewDidLoad() {
        
        super.viewDidLoad()

        self.navigationController?.navigationBar.barTintColor = kentColor
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName:UIColor.white]
        self.navigationController?.navigationBar.tintColor = UIColor.white
        
        // Register the table view cell class and its reuse id
        self.calenderTableView.register(UITableViewCell.self, forCellReuseIdentifier: cellReuseIdentifier)
        
        _ = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.enterData), userInfo: nil, repeats: true);
        
        self.checkCalenderAccess() // checks if the user has granted access to the calendar
        
        // This view controller itself will provide the delegate methods and row data for the table view.
       calenderTableView.delegate = self
        calenderTableView.dataSource = self
        
        refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(self.refresh), for: UIControlEvents.valueChanged)
        calenderTableView.addSubview(refreshControl)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    override func viewDidAppear(_ animated: Bool) {
      
    
    }
    /*method to refresh the page */
    func refresh(sender:AnyObject) {
        self.allEvents.removeAll()
        self.calenderTableView.reloadData()
        lblNoEvents.text = ""
        refreshControl.endRefreshing()
        self.check = 0
        self.checkCalenderAccess()
    
    }
    
    
    /*requests access to the calendar checks if access is granted true to the user */
    func requestAccessToCalender(){
        eventStore.requestAccess(to: .event, completion:{(granted,error) in
            
            if (granted)&&(error==nil){
                print("granted: \(granted)")
                print("error: \(String(describing: error))")
            }
            else{
                print("error \(String(describing: error))")
                self.showMessagePrompt("Permission Required", message: "Needs calender permission")
            }
        })
    }
    
    /*checks the different authorisation status of the calendar */
    func checkCalenderAccess(){
        let calenderStatus = EKEventStore.authorizationStatus(for: .event)
        
        switch (calenderStatus) {
        case EKAuthorizationStatus.notDetermined:
            requestAccessToCalender()
        case EKAuthorizationStatus.authorized:
            print("authorised to access calender")
                getEvents() // events from the calendar are retrieved when user is authorised

          
        case EKAuthorizationStatus.restricted, EKAuthorizationStatus.denied:
            self.showMessagePrompt("Permission Required", message: "Needs calender permission to access your events.\n Go to Settings ---> Privacy---> Calendars --->enable access to BuzApp.") // messsage alerting the user to allow access to the calendar from the settings
        }
    }
    /*
     method that creates a message prompt
     @param title - the title of the message
     @param message - the content of the message
     */
    func showMessagePrompt(_ title:String, message:String){
        let alert = UIAlertController.init(title: title,message: message,preferredStyle: .alert)
        alert.addAction(UIAlertAction.init(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
   
    /*
     method used to retrieve the events from the calendar
     */
    func getEvents(){
        calendars = self.eventStore.calendars(for: .event)
        
        //iterating over the selected calendars
      
        for calendar:EKCalendar in calendars{
    
                    let startDate = Date()
                    let endDate =  Date(timeIntervalSinceNow: 60*60*24*1) // end date of a period of 24 hours from the start date to allow the user to plan their events of the current day and the next day
                    let predicate = eventStore.predicateForEvents(withStart: startDate, end: endDate, calendars: [calendar])
                    let events = eventStore.events(matching: predicate)
                    
                    print("Events: \(events)")
                    
                    for event in events{
                    
                        allEvents.append(event)// append event to allEvents
                        print(allEvents)
                    }
                    
               
            }
        }
    /*method to load the events in a table view*/
    func enterData(){
        
        self.calenderTableView.reloadData()
    }
    
    /*method to get the number of events to be displayed in the table*/
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allEvents.count
    }
    /*method to display the events in the table veiw*/
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //variable type is inferred
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell")! as UITableViewCell
        
        cell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")
        
        // we know that cell is not empty now so we use ! to force unwrapping but you could also define cell as
        // let cell = (tableView.dequeue... as? UITableViewCell) ?? UITableViewCell(style: ...)
     
        // print all events from the allEvents array with the title of event and the display text with event location and the start date of the event
        if allEvents.count != 0{
            lblNoEvents.text = ""
            let eventInTable:EKEvent = self.allEvents[indexPath.row] // getting the event of the index in the array
            cell.textLabel?.text = eventInTable.title
            eventLocation = eventInTable.location!
            eventTime = eventInTable.startDate
            cell.detailTextLabel?.text = "Location: \(eventLocation) at \(eventTime.description)"
            
        } else{
            lblNoEvents.text = "No events available" // alerting the user when there are no events available from the calendar
        }
        
        
        return cell
    }
    
   
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.accessoryType = .disclosureIndicator
     
    }
    
    /*method to run when table view cell is tapped*/
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        cellint = indexPath.row
        self .performSegue(withIdentifier: "showCalanderDestSegue", sender: self)
    }
    
    /*method to prepare the showCalendarDestSegue and pass the event location and time to the Journey planner*/
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let DestViewController : JourneyPlannerViewController = segue.destination as! JourneyPlannerViewController
        DestViewController.eventLocation = allEvents[cellint].location! // setting the variable event location in Journey planner with location value from the given index from allEvents array
        DestViewController.eventTime =  allEvents[cellint].startDate // setting the variable event time in Journey planner with the start time from the given index from allEvents array
        
       
        print("cellInt: \(cellint)")
        print("event location: \(eventLocation)")
    }
    
    
}
