//
//  nearestViewController.swift
//  BuzApp
//  Created by James McIntyre on 20/10/2016
//  Refactored and adjusted by Sahib Jabbal and Marc Jean-Pierre on 01/11/2017.
//  Copyright © 2017 University of Kent. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class nearestViewController: UIViewController,UITableViewDelegate, UITableViewDataSource, CLLocationManagerDelegate {
    let kentColor = UIColor(red: 9/255, green: 53/255, blue: 90/255, alpha: 1)
    var stopAtco: [String] = []
    var stopName: [String] = []
    var stopBearing: [String] = []
    var stopLocality: [String] = []
    var stopLongitude: [Double] = []
    var stopLatitude: [Double] = []
    var stopDirection: [String] = []
    var locationManager = CLLocationManager()
    var userLong = Double()
    var userLat = Double()
    var cellint = 0
    var status = CLLocationManager.authorizationStatus()
    var check = 0
    var refreshControl: UIRefreshControl!
    
    // cell reuse id (cells that scroll out of view can be reused)
    let cellReuseIdentifier = "cell"
    
    @IBOutlet weak var lblnostops: UILabel!
  
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.barTintColor = kentColor
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName:UIColor.white]
        self.navigationController?.navigationBar.tintColor = UIColor.white
        
        // Register the table view cell class and its reuse id
        self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: cellReuseIdentifier)
        
        _ = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.enterData), userInfo: nil, repeats: true);
        
        
        // This view controller itself will provide the delegate methods and row data for the table view.
        tableView.delegate = self
        tableView.dataSource = self
        
        refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(self.refresh), for: UIControlEvents.valueChanged)
        tableView.addSubview(refreshControl)
    }

    override func viewDidAppear(_ animated:Bool){
        super.viewDidAppear(animated)
        self.locationChecker()
    }

    func refresh(sender:AnyObject) {
        self.stopAtco.removeAll()
        self.stopName.removeAll()
        self.stopBearing.removeAll()
        self.stopLocality.removeAll()
        self.stopLongitude.removeAll()
        self.stopLatitude.removeAll()
        self.stopDirection.removeAll()
        self.tableView.reloadData()
        lblnostops.text = ""
        refreshControl.endRefreshing()
        self.check = 0
        self.locationChecker()
    }
    
    func locationChecker(){
        self.locationManager.requestAlwaysAuthorization()
        
        self.locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
        
        status = CLLocationManager.authorizationStatus()
        
        if(self.status == CLAuthorizationStatus.authorizedAlways || self.status == CLAuthorizationStatus.authorizedWhenInUse) {
            _ = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(self.getBuses), userInfo: nil, repeats: false);
        }
        else {
            let alertController = UIAlertController(title: "Enable Location Services", message:
                "Please enable location services to find nearby stops", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
            
            //self.present(alertController, animated: true, completion: nil)
        }
    }
    
    func enterData(){
        
        self.tableView.reloadData()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        userLat = locValue.latitude
        userLong = locValue.longitude
    }
    
    // number of rows in table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.stopName.count
    }
    
    // create a cell for each table view row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //variable type is inferred
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell")! as UITableViewCell
        
        cell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")
        
        // we know that cell is not empty now so we use ! to force unwrapping but you could also define cell as
        // let cell = (tableView.dequeue... as? UITableViewCell) ?? UITableViewCell(style: ...)
        let imageName = "busstop.png"
        let image = UIImage(named: imageName)
        cell.imageView!.image = image
        
        if stopName.count != 0{
            lblnostops.text = ""
            cell.textLabel?.text = self.stopName[indexPath.row]
            
        }
        
        if stopDirection.count == 7 {
            cell.detailTextLabel?.text = "towards: \(self.stopDirection[indexPath.row])"
        }
        
        return cell
    }
   
  
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.accessoryType = .disclosureIndicator
    }
    
    
    //method to run when table view cell is tapped
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        cellint = indexPath.row
        // adding the recent stop to recents
        if (!recStopNames.contains(stopName[cellint])){
        // adds recents stops to recents
        recStopNames.append(stopName[cellint])
        recStopAtco.append(stopAtco[cellint])
        recStopLocality.append(stopLocality[cellint])
        recStopLongitude.append(stopLongitude[cellint])
        recStopLatitude.append(stopLatitude[cellint])
       
        
        
        // stores the user defaults to the value  in recent stops
        UserDefaults.standard.set(recStopNames, forKey: "myrecents")
        UserDefaults.standard.set(recStopAtco, forKey: "myrecentsAtco")
        UserDefaults.standard.set(recStopLocality, forKey: "myrecentsLocality")
        UserDefaults.standard.set(recStopLatitude, forKey: "myrecentsLatitude")
        UserDefaults.standard.set(recStopLongitude, forKey: "myrecentsLongitude")
        }
       self .performSegue(withIdentifier: "showStopSegue", sender: self)
    }
    
    func getBuses() {
        
        if check == 0 {
            //URL string for nearest buses
            let urlString = "https://transportapi.com/v3/uk/bus/stops/near.json?app_id=a8fbdc15&app_key=b3d5f933e236d4c2572657618ba78394&lat=\(userLat)&lon=\(userLong)&rpp=7"
            
            let url = URL(string: urlString)
            URLSession.shared.dataTask(with:url!, completionHandler: {(data, response, error) in
                if error != nil {
                    print(error)
                } else {
                    do {
                        
                        let parsedData = try JSONSerialization.jsonObject(with: data!, options: .allowFragments)
                        let dictionary = parsedData as? [String: AnyObject]
                        
                        if let stops = dictionary?["stops"] as? [[String: AnyObject]] {
                            print(stops)
                            
                            
                            for index in 0...stops.count-1 {
                                let aObject = stops[index]
                                self.stopAtco.append(aObject["atcocode"] as! String)
                                self.stopName.append(aObject["name"] as! String)
                                self.stopBearing.append(aObject["bearing"] as! String)
                                self.stopLocality.append(aObject["locality"] as! String)
                                self.stopLongitude.append(aObject["longitude"] as! Double)
                                self.stopLatitude.append(aObject["latitude"] as! Double)
                                
                            }
                            self.check = 1
                            self.getDirection()
                        }
                        
                    } catch let error as NSError {
                        print(error)
                    }
                }
                
            }).resume()
        }
        
    }
    //Gets direction that the bus is going in
    func getDirection() {
        
        let limit = 5
        
        for index2 in 0...stopAtco.count-1{
            
            //URL string for bus stop with acto code
            let urlString2 = "https://transportapi.com/v3/uk/bus/stop/\(stopAtco[index2])/live.json?app_id=a8fbdc15&app_key=b3d5f933e236d4c2572657618ba78394&group=no&limit=\(limit)&nextbuses=yes"
            print(urlString2)
            let url2 = URL(string: urlString2)
            URLSession.shared.dataTask(with:url2!, completionHandler: {(data, response, error) in
                if error != nil {
                    print(error)
                } else {
                    do {
                        
                        let parsedData2 = try JSONSerialization.jsonObject(with: data!, options: .allowFragments)
                        let dictionary2 = parsedData2 as? [String: AnyObject]
                        
                        let dep2 = dictionary2?["departures"] as? [String: AnyObject]   //! [NSObject: AnyObject]
                        
                        if let arrDep2 = dep2?["all"] as? [[String: AnyObject]] {
                            
                            let aObject2 = arrDep2[0]
                            
                            print(aObject2["direction"] as! String)
                            self.stopDirection.append(aObject2["direction"] as! String)
                        }
                        else{
                            self.stopDirection.append("No buses")
                        }
                    } catch let error as NSError {
                        print(error)
                    }
                }
                
            }).resume()
        }
        
    }
    
   
    // Tapping the cell in the table links to the Bus Stop View Controller. This prepares the view by sending the variables that it needs
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let DestViewController : BusStopViewController = segue.destination as! BusStopViewController
        
        DestViewController.busStopName = stopName[cellint]
        DestViewController.busAtcocode = stopAtco[cellint]
        DestViewController.busLocality = stopLocality[cellint]
        DestViewController.busLong = stopLongitude[cellint]
        DestViewController.busLat = stopLatitude[cellint]
        print(cellint)
        print(stopName[cellint])
    }

}
