//
//  JourneyPlannerCell.swift
//  BuzApp
//
//  Created by Marc Jean-Pierre on 06/02/2018.
//  Copyright © 2018 University of Kent. All rights reserved.
//

import UIKit

class JourneyPlannerCell: UITableViewCell {
    
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var nameLbl2: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
