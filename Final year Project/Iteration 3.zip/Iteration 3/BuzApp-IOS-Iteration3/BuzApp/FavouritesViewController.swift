//
//  FavouritesViewController.swift
//  BuzApp
//
//  Created by Sahib Jabbal and Marc Jean-Pierre on 11/11/2017.
//  Copyright © 2017 University of Kent. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit
var favStopNames: [String] = []
var favStopAtco: [String] = []
var favStopLocality: [String] = []
var favStopLatitude: [Double] = []
var favStopLongitude: [Double] = []
class FavouritesViewController: UIViewController,UITableViewDelegate, UITableViewDataSource,  CLLocationManagerDelegate{
    

    @IBOutlet weak var lblnofavourites: UILabel!
    @IBOutlet weak var favouritesTableView: UITableView!
    let kentColor = UIColor(red: 9/255, green: 53/255, blue: 90/255, alpha: 1)
    var favStopName = String()
    var stopBearing: [String] = []
    var stopDirection: [String] = []
    //var favStopNames: [String] = []
    var favBus: [String] = []
    var locationManager = CLLocationManager()
    var userLong = Double()
    var userLat = Double()
    var cellint = 0
    var status = CLLocationManager.authorizationStatus()
    var check = 0
    var refreshControl: UIRefreshControl!
    // cell reuse id (cells that scroll out of view can be reused)
    let cellReuseIdentifier = "cell"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.barTintColor = kentColor
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName:UIColor.white]
        self.navigationController?.navigationBar.tintColor = UIColor.white
        
        // Register the table view cell class and its reuse id
        self.favouritesTableView.register(UITableViewCell.self, forCellReuseIdentifier: cellReuseIdentifier)
        
        _ = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.enterData), userInfo: nil, repeats: true);
        
        
        // This view controller itself will provide the delegate methods and row data for the table view.
        favouritesTableView.delegate = self
        favouritesTableView.dataSource = self
        
        refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(self.refresh), for: UIControlEvents.valueChanged)
        favouritesTableView.addSubview(refreshControl)

        print(favStopNames)
    }
    //Once the view appears, it loads the user's defaults for their favourite stops
    override func viewDidAppear(_ animated:Bool){
        super.viewDidAppear(animated)
        if let favStop = UserDefaults.standard.object(forKey: "myfavourites") as? [String]{
            favStopNames = favStop
            print("Values of fav sop is = \(favStop)")
            
        }
        
        if let favStopAtcode = UserDefaults.standard.object(forKey: "myfavouritesAtco") as? [String]{
            favStopAtco = favStopAtcode
            print("Values of fav atco is = \(favStopAtcode)")
            
        }
        if let favStopLocal = UserDefaults.standard.object(forKey: "myfavouritesLocality") as? [String]{
            favStopLocality = favStopLocal
            print("Values of fav local is = \(favStopLocal)")
            
        }
        if let favStopLong = UserDefaults.standard.object(forKey: "myfavouritesLongitude") as? [Double]{
            favStopLongitude = favStopLong
            print("Values of fav long is = \(favStopLong)")
            
        }
        if let favStopLat = UserDefaults.standard.object(forKey: "myfavouritesLatitude") as? [Double]{
            favStopLatitude = favStopLat
            print("Values of fav lat is = \(favStopLat)")
            
        }
    }
    
  
    func refresh(sender:AnyObject) {
       favStopAtco.removeAll()
        //self.favStopName.removeAll()
        self.stopBearing.removeAll()
        favStopLocality.removeAll()
        favStopLongitude.removeAll()
        favStopLatitude.removeAll()
        self.stopDirection.removeAll()
        self.favouritesTableView.reloadData()
        lblnofavourites.text = ""
        refreshControl.endRefreshing()
        self.check = 0
       
        
    }
    
    func enterData(){
        
        self.favouritesTableView.reloadData()
    }
    
    //The table is built with the number of stops in the array
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return favStopNames.count

    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //variable type is inferred
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell")! as UITableViewCell
        
        cell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")
        
        // we know that cell is not empty now so we use ! to force unwrapping but you could also define cell as
        // let cell = (tableView.dequeue... as? UITableViewCell) ?? UITableViewCell(style: ...)
        let imageName = "busstop.png"
        let image = UIImage(named: imageName)
        cell.imageView!.image = image
        
        if favStopNames.count != 0{
            lblnofavourites.text = ""
            cell.textLabel?.text = favStopNames[indexPath.row]
            
        }
        
        if stopDirection.count >= 1 {
            cell.detailTextLabel?.text = "towards: \(self.stopDirection[indexPath.row])"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.accessoryType = .disclosureIndicator
    }
    /*
     When the cell is tapped it checks that the stop isn't in the users recents already.
     If not it adds this stop to the users recents and stores in the users defaults
     This then opens the Bus Stop View Controller with the bus stop tapped
     */
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        cellint = indexPath.row
        if (!recStopNames.contains(favStopNames[cellint])){
            // adds recent stop in recents
            recStopNames.append(favStopNames[cellint])
            recStopAtco.append(favStopAtco[cellint])
            recStopLocality.append(favStopLocality[cellint])
            recStopLongitude.append(favStopLongitude[cellint])
            recStopLatitude.append(favStopLatitude[cellint])
            
            
            
            // stores the user defaults to the value  in recStopNames
            UserDefaults.standard.set(recStopNames, forKey: "myrecents")
            UserDefaults.standard.set(recStopAtco, forKey: "myrecentsAtco")
            UserDefaults.standard.set(recStopLocality, forKey: "myrecentsLocality")
            UserDefaults.standard.set(recStopLatitude, forKey: "myrecentsLatitude")
            UserDefaults.standard.set(recStopLongitude, forKey: "myrecentsLongitude")
        }
        self .performSegue(withIdentifier: "showFavouritesInfoSegue", sender: self)
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    //This function allows the user to delete their favourite bus directly from the list
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle,forRowAt indexPath: IndexPath)
    {
        if editingStyle == .delete
        {
         // delete favourite bus stop by swiping to the left
            favStopNames.remove(at:indexPath.row)
            favStopAtco.remove(at:indexPath.row)
            favStopLocality.remove(at:indexPath.row)
            favStopLatitude.remove(at:indexPath.row)
            favStopLongitude.remove(at:indexPath.row)
            
           tableView.beginUpdates()
            tableView.deleteRows(at: [indexPath], with: .automatic)
            tableView.endUpdates()
            
            // updates the user defaults with the updated favourite lists
            UserDefaults.standard.set(favStopNames, forKey: "myfavourites")
            UserDefaults.standard.set(favStopAtco, forKey: "myfavouritesAtco")
            UserDefaults.standard.set(favStopLocality, forKey: "myfavouritesLocality")
            UserDefaults.standard.set(favStopLatitude, forKey: "myfavouritesLatitude")
            UserDefaults.standard.set(favStopLongitude, forKey: "myfavouritesLongitude")
        
        }
    }
    
    // get favourite stops
    func getFavouriteStops(){
       if check == 0 {
            //URL string for favorite buses
            
            for index in 0...favStopNames.count-1{
                let urlString = "https://transportapi.com/v3/uk/bus/stops/\(favStopNames[index])/live.json?app_id=a8fbdc15&app_key=b3d5f933e236d4c2572657618ba78394&lat=\(favStopLatitude[index])&lon=\(favStopLongitude[index])"
                
                let url = URL(string: urlString)
                URLSession.shared.dataTask(with:url!, completionHandler: {(data, response, error) in
                    if error != nil {
                        print(error)
                    } else {
                        do {
                            
                            let parsedData = try JSONSerialization.jsonObject(with: data!, options: .allowFragments)
                            let dictionary = parsedData as? [String: AnyObject]
                            
                            if let stops = dictionary?["stops"] as? [[String: AnyObject]] {
                                print(stops)
                                
                                
                                for index in 0...stops.count-1 {
                                    let aObject = stops[index]
                                    favStopAtco.append(aObject["atcocode"] as! String)
                                    favStopNames.append(aObject["name"] as! String)
                                    self.stopBearing.append(aObject["bearing"] as! String)
                                    favStopLocality.append(aObject["locality"] as! String)
                                    favStopLongitude.append(aObject["longitude"] as! Double)
                                   favStopLatitude.append(aObject["latitude"] as! Double)
                                    
                                }
                                self.check = 1
                                self.getDirection()
                            }
                            
                        } catch let error as NSError {
                            print(error)
                        }
                    }
                    
                }).resume()
            }
                
            }
           
    }
    //Gets the direction that the bus is going in
    func getDirection(){
        let limit = 5
        
        for index2 in 0...favStopAtco.count-1{
            
            //URL string for bus stop with acto code
            let urlString2 = "https://transportapi.com/v3/uk/bus/stop/\(favStopAtco[index2])/live.json?app_id=a8fbdc15&app_key=b3d5f933e236d4c2572657618ba78394&group=no&limit=\(limit)&nextbuses=yes"
            print(urlString2)
            let url2 = URL(string: urlString2)
            URLSession.shared.dataTask(with:url2!, completionHandler: {(data, response, error) in
                if error != nil {
                    print(error)
                } else {
                    do {
                        
                        let parsedData2 = try JSONSerialization.jsonObject(with: data!, options: .allowFragments)
                        let dictionary2 = parsedData2 as? [String: AnyObject]
                        
                        let dep2 = dictionary2?["departures"] as? [String: AnyObject]   //! [NSObject: AnyObject]
                        
                        if let arrDep2 = dep2?["all"] as? [[String: AnyObject]] {
                            
                            let aObject2 = arrDep2[0]
                            
                            print(aObject2["direction"] as! String)
                            self.stopDirection.append(aObject2["direction"] as! String)
                        }
                        else{
                            self.stopDirection.append("No buses")
                        }
                    } catch let error as NSError {
                        print(error)
                    }
                }
                
            }).resume()
        }
    }
    // As table cell links to the bus stop view Controller, prepares this view by sending value of variables
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let DestViewController : BusStopViewController = segue.destination as! BusStopViewController
        
        DestViewController.busStopName = favStopNames[cellint]
        DestViewController.busAtcocode = favStopAtco[cellint]
        DestViewController.busLocality = favStopLocality[cellint]
        DestViewController.busLong = favStopLongitude[cellint]
        DestViewController.busLat = favStopLatitude[cellint]
        print(cellint)
        print(favStopNames[cellint])
    }
    
  

}
