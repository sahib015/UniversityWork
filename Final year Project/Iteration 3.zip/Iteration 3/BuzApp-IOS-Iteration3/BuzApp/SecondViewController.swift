//
//  SecondViewController.swift
//  BuzApp
//
//  Created by James McIntyre on 20/10/2016.
//  Copyright © 2016 University of Kent. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class SecondViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    
    @IBOutlet weak var map: MKMapView!
    var locationManager = CLLocationManager()
    let kentColor = UIColor(red: 9/255, green: 53/255, blue: 90/255, alpha: 1)
    let regionRadius: CLLocationDistance = 400
    var stopAtco: [String] = []
    var stopName: [String] = []
    var stopBearing: [String] = []
    var stopLocality: [String] = []
    var stopLongitude: [Double] = []
    var stopLatitude: [Double] = []
    var stopDirection: [String] = []
    var userLong = Double()
    var userLat = Double()
    var location = CLLocation()
    var checker = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.navigationController?.navigationBar.barTintColor = kentColor
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName:UIColor.white]
        self.navigationController?.navigationBar.tintColor = UIColor.white
        
        //One or other below, ask guys
        self.locationManager.requestAlwaysAuthorization()
        self.locationManager.requestWhenInUseAuthorization()

        self.getLocation()
        
        //wait for user location
        _ = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.getBuses), userInfo: nil, repeats: false);
        
        _ = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.pinMap), userInfo: nil, repeats: true);
        
    }

    func getLocation() {
        //Getting user location
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
            map.showsUserLocation = true
        }
    }
    
    func getBuses() {
        
        //URL string for nearest buses
        let urlString = "https://transportapi.com/v3/uk/bus/stops/near.json?app_id=a8fbdc15&app_key=b3d5f933e236d4c2572657618ba78394&lat=\(userLat)&lon=\(userLong)&rpp=7"
        
        let url = URL(string: urlString)
        URLSession.shared.dataTask(with:url!, completionHandler: {(data, response, error) in
            if error != nil {
                print(error)
            } else {
                do {
                    
                    let parsedData = try JSONSerialization.jsonObject(with: data!, options: .allowFragments)
                    let dictionary = parsedData as? [String: AnyObject]
                    
                    if let stops = dictionary?["stops"] as? [[String: AnyObject]] {
                        print(stops)
                        
                        
                        for index in 0...stops.count-1 {
                            let aObject = stops[index]
                            self.stopAtco.append(aObject["atcocode"] as! String)
                            self.stopName.append(aObject["name"] as! String)
                            self.stopBearing.append(aObject["bearing"] as! String)
                            self.stopLocality.append(aObject["locality"] as! String)
                            self.stopLongitude.append(aObject["longitude"] as! Double)
                            self.stopLatitude.append(aObject["latitude"] as! Double)
                        }
                        self.getDirection()
                    }
                    
                } catch let error as NSError {
                    print(error)
                }
            }
            
        }).resume()
    }
    
    func getDirection() {
        
        let limit = 5
        
        for index2 in 0...stopAtco.count-1{
            
            //URL string for bus stop with acto code
            let urlString2 = "https://transportapi.com/v3/uk/bus/stop/\(stopAtco[index2])/live.json?app_id=a8fbdc15&app_key=b3d5f933e236d4c2572657618ba78394&group=no&limit=\(limit)&nextbuses=yes"
            
            let url2 = URL(string: urlString2)
            URLSession.shared.dataTask(with:url2!, completionHandler: {(data, response, error) in
                if error != nil {
                    print(error)
                } else {
                    do {
                        let parsedData2 = try JSONSerialization.jsonObject(with: data!, options: .allowFragments)
                        let dictionary2 = parsedData2 as? [String: AnyObject]
                        let dep2 = dictionary2?["departures"] as? [String: AnyObject]
                        
                        if let arrDep2 = dep2?["all"] as? [[String: AnyObject]] {
                            let aObject2 = arrDep2[0]
                            print(aObject2["direction"] as! String)
                            self.stopDirection.append(aObject2["direction"] as! String)
                        }
                        
                        else {
                            self.stopDirection.append("No buses")
                        }

                    } catch let error as NSError {
                        print(error)
                    }
                }
                
            }).resume()
        }
        
        let initialLocation = CLLocation(latitude: stopLatitude[0], longitude: stopLongitude[0])
        centerMapOnLocation(location: initialLocation)
    }
    
    
    func pinMap() {
        if checker == 1 {
        if stopDirection.count == 7 {
            //List buses instead of loop to set unique pin values
                let newPin0 = BusStop(title: stopName[0],
                                     direction: "towards: " + stopDirection[0],
                                     discipline: "Bus Stop",
                                     coordinate: CLLocationCoordinate2D(latitude: stopLatitude[0], longitude: stopLongitude[0]))
                map.addAnnotation(newPin0)
                let newPin1 = BusStop(title: stopName[1],
                                      direction: "towards: " + stopDirection[1],
                                      discipline: "Bus Stop",
                                      coordinate: CLLocationCoordinate2D(latitude: stopLatitude[1], longitude: stopLongitude[1]))
                map.addAnnotation(newPin1)
                let newPin2 = BusStop(title: stopName[2],
                                      direction: "towards: " + stopDirection[2],
                                      discipline: "Bus Stop",
                                      coordinate: CLLocationCoordinate2D(latitude: stopLatitude[2], longitude: stopLongitude[2]))
                map.addAnnotation(newPin2)
                let newPin3 = BusStop(title: stopName[3],
                                      direction: "towards: " + stopDirection[3],
                                      discipline: "Bus Stop",
                                      coordinate: CLLocationCoordinate2D(latitude: stopLatitude[3], longitude: stopLongitude[3]))
                map.addAnnotation(newPin3)
                let newPin4 = BusStop(title: stopName[4],
                                      direction: "towards: " + stopDirection[4],
                                      discipline: "Bus Stop",
                                      coordinate: CLLocationCoordinate2D(latitude: stopLatitude[4], longitude: stopLongitude[4]))
                map.addAnnotation(newPin4)
                let newPin5 = BusStop(title: stopName[5],
                                      direction: "towards: " + stopDirection[5],
                                      discipline: "Bus Stop",
                                      coordinate: CLLocationCoordinate2D(latitude: stopLatitude[5], longitude: stopLongitude[5]))
                map.addAnnotation(newPin5)
                let newPin6 = BusStop(title: stopName[6],
                                      direction: "towards: " + stopDirection[6],
                                      discipline: "Bus Stop",
                                      coordinate: CLLocationCoordinate2D(latitude: stopLatitude[6], longitude: stopLongitude[6]))
                map.addAnnotation(newPin6)
            checker = 0
        }
        }
    }
    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,
                                                                  regionRadius * 1.0, regionRadius * 1.0)
        map.setRegion(coordinateRegion, animated: true)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        userLat = locValue.latitude
        userLong = locValue.longitude
    }
    
}

