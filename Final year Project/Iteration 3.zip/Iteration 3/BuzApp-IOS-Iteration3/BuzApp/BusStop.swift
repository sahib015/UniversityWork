//
//  BusStop.swift
//  BuzApp
//
//  Created by Admin on 02/11/2016.
//  Copyright © 2016 University of Kent. All rights reserved.
//

import Foundation
import MapKit

class BusStop: NSObject, MKAnnotation {
    let title: String?
    let direction: String?
    let discipline: String
    let coordinate: CLLocationCoordinate2D
    
    init(title: String, direction: String, discipline: String, coordinate: CLLocationCoordinate2D) {
        self.title = title
        self.direction = direction
        self.discipline = discipline
        self.coordinate = coordinate
        
        super.init()
    }
    
    var subtitle: String? {
        return direction
    }

}
