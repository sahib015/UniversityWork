//
//  recentsViewController.swift
//  BuzApp
//
//  Created by Marc Jean-Pierre and Sahib Jabbal on 01/11/2017.
//  Copyright © 2017 University of Kent. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit
var recStopNames: [String] = []
var recStopAtco: [String] = []
var recStopLocality: [String] = []
var recStopLatitude: [Double] = []
var recStopLongitude: [Double] = []

class recentsViewController:UIViewController,UITableViewDelegate, UITableViewDataSource,  CLLocationManagerDelegate {

    @IBOutlet weak var lblnorecent: UILabel!
    @IBOutlet weak var recentsTableView: UITableView!
    let kentColor = UIColor(red: 9/255, green: 53/255, blue: 90/255, alpha: 1)
    var recStopName = String()
    var stopBearing: [String] = []
    var stopDirection: [String] = []
    var recBus: [String] = []
    var locationManager = CLLocationManager()
    var userLong = Double()
    var userLat = Double()
    var cellint = 0
    var status = CLLocationManager.authorizationStatus()
    var check = 0
    var refreshControl: UIRefreshControl!
    // cell reuse id (cells that scroll out of view can be reused)
    let cellReuseIdentifier = "cell"
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.barTintColor = kentColor
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName:UIColor.white]
        self.navigationController?.navigationBar.tintColor = UIColor.white
        
        // Register the table view cell class and its reuse id
        self.recentsTableView.register(UITableViewCell.self, forCellReuseIdentifier: cellReuseIdentifier)
        
        _ = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.enterData), userInfo: nil, repeats: true);
        
        
        // This view controller itself will provide the delegate methods and row data for the table view.
        recentsTableView.delegate = self
        recentsTableView.dataSource = self
        
        refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(self.refresh), for: UIControlEvents.valueChanged)
        recentsTableView.addSubview(refreshControl)
        
        print(recStopNames)
    }
    //When the view loads it sets the user defaults to the stops that they have selected
    override func viewDidAppear(_ animated:Bool){
        super.viewDidAppear(animated)
        if let recStop = UserDefaults.standard.object(forKey: "myrecents") as? [String]{
            recStopNames = recStop
            print("Values of rec sop is = \(recStop)")
            
        }
        
        if let recStopAtcode = UserDefaults.standard.object(forKey: "myrecentsAtco") as? [String]{
            recStopAtco = recStopAtcode
            print("Values of rec atco is = \(recStopAtcode)")
            
        }
        if let recStopLocal = UserDefaults.standard.object(forKey: "myrecentsLocality") as? [String]{
            recStopLocality = recStopLocal
            print("Values of rec local is = \(recStopLocal)")
            
        }
        if let recStopLong = UserDefaults.standard.object(forKey: "myrecentsLongitude") as? [Double]{
            recStopLongitude = recStopLong
            print("Values of rec long is = \(recStopLong)")
            
        }
        if let recStopLat = UserDefaults.standard.object(forKey: "myrecentsLatitude") as? [Double]{
            recStopLatitude = recStopLat
            print("Values of rec lat is = \(recStopLat)")
            
        }
    }
   //Refreshes the view once the table is pulled down
    func refresh(sender:AnyObject) {
        recStopAtco.removeAll()
    
        self.stopBearing.removeAll()
        recStopLocality.removeAll()
        recStopLongitude.removeAll()
        recStopLatitude.removeAll()
        self.stopDirection.removeAll()
        self.recentsTableView.reloadData()
        lblnorecent.text = ""
        refreshControl.endRefreshing()
        self.check = 0
        
        
    }
    
    func enterData(){
        
        self.recentsTableView.reloadData()
    }
    
    //Builds the table view with the number of recents stops in the array
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return recStopNames.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //variable type is inferred
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell")! as UITableViewCell
        
        cell = UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")
        
        // we know that cell is not empty now so we use ! to force unwrapping but you could also define cell as
        // let cell = (tableView.dequeue... as? UITableViewCell) ?? UITableViewCell(style: ...)
        let imageName = "busstop.png"
        let image = UIImage(named: imageName)
        cell.imageView!.image = image
        
        if recStopNames.count != 0{
            lblnorecent.text = ""
            cell.textLabel?.text = recStopNames[indexPath.row]
            
        }
        
        if stopDirection.count >= 1 {
            cell.detailTextLabel?.text = "towards: \(self.stopDirection[indexPath.row])"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.accessoryType = .disclosureIndicator
    }
    
    //This method is called when a cell is tapped, linking to the bus stop view Controller
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        cellint = indexPath.row
        self .performSegue(withIdentifier: "showRecentsInfoSegue", sender: self)
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    //Used so the user can delete a stop directly from the table
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle,forRowAt indexPath: IndexPath)
    {
        if editingStyle == .delete
        {
            // delete favourite bus stop by swiping to the left
            recStopNames.remove(at:indexPath.row)
            recStopAtco.remove(at:indexPath.row)
            recStopLocality.remove(at:indexPath.row)
            recStopLatitude.remove(at:indexPath.row)
            recStopLongitude.remove(at:indexPath.row)
            
            tableView.beginUpdates()
            tableView.deleteRows(at: [indexPath], with: .automatic)
            tableView.endUpdates()
            
            // updates the user defaults with the updated favourite lists
            UserDefaults.standard.set(recStopNames, forKey: "myrecents")
            UserDefaults.standard.set(recStopAtco, forKey: "myrecentsAtco")
            UserDefaults.standard.set(recStopLocality, forKey: "myrecentsLocality")
            UserDefaults.standard.set(recStopLatitude, forKey: "myrecentsLatitude")
            UserDefaults.standard.set(recStopLongitude, forKey: "myrecentsLongitude")
            
        }
    }
    
    // get recents stops
    func getRecentStops(){
        if check == 0 {
            //URL string for favorite buses
            
            for index in 0...recStopNames.count-1{
                let urlString = "https://transportapi.com/v3/uk/bus/stops/\(recStopNames[index])/live.json?app_id=a8fbdc15&app_key=b3d5f933e236d4c2572657618ba78394&lat=\(recStopLatitude[index])&lon=\(recStopLongitude[index])"
                
                let url = URL(string: urlString)
                URLSession.shared.dataTask(with:url!, completionHandler: {(data, response, error) in
                    if error != nil {
                        print(error)
                    } else {
                        do {
                            
                            let parsedData = try JSONSerialization.jsonObject(with: data!, options: .allowFragments)
                            let dictionary = parsedData as? [String: AnyObject]
                            
                            if let stops = dictionary?["stops"] as? [[String: AnyObject]] {
                                print(stops)
                                
                                
                                for index in 0...stops.count-1 {
                                    let aObject = stops[index]
                                    recStopAtco.append(aObject["atcocode"] as! String)
                                    recStopNames.append(aObject["name"] as! String)
                                    self.stopBearing.append(aObject["bearing"] as! String)
                                    recStopLocality.append(aObject["locality"] as! String)
                                    recStopLongitude.append(aObject["longitude"] as! Double)
                                    recStopLatitude.append(aObject["latitude"] as! Double)
                                    
                                }
                                self.check = 1
                                self.getDirection()
                            }
                            
                        } catch let error as NSError {
                            print(error)
                        }
                    }
                    
                }).resume()
            }
            
        }
        
    }
    //Gets the direction that the buses are headed in
    func getDirection(){
        let limit = 5
        
        for index2 in 0...recStopAtco.count-1{
            
            //URL string for bus stop with acto code
            let urlString2 = "https://transportapi.com/v3/uk/bus/stop/\(recStopAtco[index2])/live.json?app_id=a8fbdc15&app_key=b3d5f933e236d4c2572657618ba78394&group=no&limit=\(limit)&nextbuses=yes"
            print(urlString2)
            let url2 = URL(string: urlString2)
            URLSession.shared.dataTask(with:url2!, completionHandler: {(data, response, error) in
                if error != nil {
                    print(error)
                } else {
                    do {
                        
                        let parsedData2 = try JSONSerialization.jsonObject(with: data!, options: .allowFragments)
                        let dictionary2 = parsedData2 as? [String: AnyObject]
                        
                        let dep2 = dictionary2?["departures"] as? [String: AnyObject]   //! [NSObject: AnyObject]
                        
                        if let arrDep2 = dep2?["all"] as? [[String: AnyObject]] {
                            
                            let aObject2 = arrDep2[0]
                            
                            print(aObject2["direction"] as! String)
                            self.stopDirection.append(aObject2["direction"] as! String)
                        }
                        else{
                            self.stopDirection.append("No buses")
                        }
                    } catch let error as NSError {
                        print(error)
                    }
                }
                
            }).resume()
        }
    }
    // As table cell links to the bus stop view Controller, prepares this view by sending value of variables
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let DestViewController : BusStopViewController = segue.destination as! BusStopViewController
        
        DestViewController.busStopName = recStopNames[cellint]
        DestViewController.busAtcocode = recStopAtco[cellint]
        DestViewController.busLocality = recStopLocality[cellint]
        DestViewController.busLong = recStopLongitude[cellint]
        DestViewController.busLat = recStopLatitude[cellint]
        print(cellint)
        print(recStopNames[cellint])
    }

}

    

  


