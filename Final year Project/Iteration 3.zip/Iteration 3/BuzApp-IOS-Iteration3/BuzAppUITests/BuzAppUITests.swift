//
//  BuzAppUITests.swift
//  BuzAppUITests
//
//  Created by James McIntyre on 20/10/2016.
// Edited by Sahib Jabbal and Marc Jean-Pierre
//  Copyright © 2016 University of Kent. All rights reserved.
//

import XCTest

class BuzAppUITests: XCTestCase {
        
    override func setUp() {
        super.setUp()
        
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false
        // UI tests must launch the application that they test. Doing this in setup will make sure it happens for each test method.
        XCUIApplication().launch()

        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    

    
  
    
    func testAddDeleteFavourites(){
        
        
        let app = XCUIApplication()
        let keynesCollegeStopAStaticText = app.tables/*@START_MENU_TOKEN@*/.staticTexts["Keynes College (Stop A)"]/*[[".cells.staticTexts[\"Keynes College (Stop A)\"]",".staticTexts[\"Keynes College (Stop A)\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/
        XCTAssertEqual(keynesCollegeStopAStaticText.exists,true)
        
        keynesCollegeStopAStaticText.tap()
        
        let keynesCollegeStopANavigationBar = app.navigationBars["Keynes College (Stop A)"]
        let button = keynesCollegeStopANavigationBar.children(matching: .button).element(boundBy: 1)
        XCTAssertTrue(button.exists)
        button.tap()
        
        let okButton = app.alerts["BuzzApp"].buttons["Ok"]
        okButton.tap()
        keynesCollegeStopANavigationBar.buttons["Back"].tap()
        app.navigationBars["BuzApp.FirstView"]/*@START_MENU_TOKEN@*/.buttons["Favourites"]/*[[".staticTexts.buttons[\"Favourites\"]",".buttons[\"Favourites\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
        XCTAssertEqual(keynesCollegeStopAStaticText.exists,true)
        keynesCollegeStopAStaticText.tap()
        button.tap()
        okButton.tap()
      
        
    }
    
    func testAddtoRecents()
    {
        let app = XCUIApplication()
        let tablesQuery = app.tables
        let innovationCenter = tablesQuery.children(matching: .cell).element(boundBy: 4).staticTexts["Innovation Centre"]
        innovationCenter.tap()
        let innovationNavBar = app.navigationBars["Innovation Centre"]
        innovationNavBar.buttons["Back"].tap()
        app.navigationBars/*@START_MENU_TOKEN@*/.buttons["Recents"]/*[[".staticTexts.buttons[\"Recents\"]",".buttons[\"Recents\"]"],[[[-1,1],[-1,0]]],[0]]@END_MENU_TOKEN@*/.tap()
      
        
    }
    
    func testCalendar(){
        
        let app = XCUIApplication()
        app.tabBars.buttons["Calendar"].tap()
        let firstElement = app.tables.children(matching: .any).element(boundBy:0)
        if firstElement.exists{
            firstElement.tap()
            app.searchFields.containing(.button, identifier:"Clear text").element.tap()
        }
    }

}
