//
//  BusInfoViewController.swift
//  BuzApp
//
//  Created by James McIntyre on 08/02/2017.
//  Copyright © 2017 University of Kent. All rights reserved.
//

import Foundation
import UIKit
import MapKit

class BusInfoViewController: UIViewController, UITableViewDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var tableView: UITableView!
    var locationManager = CLLocationManager()
    let regionRadius: CLLocationDistance = 400
    var stopName = String()
    var stopAtco = String()
    var busDirectionCode = String()
    var busLine = String()
    var busOperator = String()
    var busDate = String()
    var busAtcoCode = String()
    var busAimedTime = String()
    var busBestTime = String()
    var stopNames: [String] = []
    var stopTimes: [String] = []
    var stopTimesLeft: [String] = []
    var stopIndicator: [String] = []
    var stopLong: [Double] = []
    var stopLat: [Double] = []
    var check = 0
    
    // cell reuse id (cells that scroll out of view can be reused)
    let cellReuseIdentifier = "cell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if busDirectionCode == "noroute" {
            self.navigationItem.title = "No route information" 
        } else {
            self.navigationItem.title = busLine + " - Route"
        }
    
        self.locationManager.requestWhenInUseAuthorization()
        self.getLocation()
        getBusInfo()
    }
    
    func getLocation() {
        //Getting user location
        if CLLocationManager.locationServicesEnabled() {
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
            mapView.showsUserLocation = true
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func getBusInfo() {
        
        if check == 0 {
            //URL string for bus stop with acto code
            let urlString = "https://transportapi.com/v3/uk/bus/route/\(busOperator)/\(busLine)/\(busDirectionCode)/\(busAtcoCode)/\(busDate)/\(busAimedTime)/timetable.json?app_id=a8fbdc15&app_key=b3d5f933e236d4c2572657618ba78394&stops=all"
            
            let url = URL(string: urlString)
            URLSession.shared.dataTask(with:url!, completionHandler: {(data, response, error) in
                if error != nil {
                    print(error)
                } else {
                    do {
                        
                        let parsedData = try JSONSerialization.jsonObject(with: data!, options: .allowFragments)
                        let dictionary = parsedData as? [String: AnyObject]
                        
                        if let stops = dictionary?["stops"] as? [[String: AnyObject]] {
                            print(stops)

                            for index in 0...stops.count-1 {
                                let aObject = stops[index]
                                self.stopNames.append(aObject["name"] as! String)
                                self.stopIndicator.append(aObject["indicator"] as! String)
                                self.stopTimes.append(aObject["time"] as! String)
                                self.stopTimesLeft.append(aObject["time"] as! String)
                                self.stopLat.append(aObject["latitude"] as! Double)
                                self.stopLong.append(aObject["longitude"] as! Double)
                            }
                            
                            let date = Date()
                            let calendar = Calendar.current
                            let hour = (calendar.component(.hour, from: date))
                            let minutes = calendar.component(.minute, from: date)
                            print("hours = \(hour):\(minutes)")
                            
                            for busIndex in 0 ... stops.count-1 {
                                
                                let startIndex = self.stopTimesLeft[busIndex].index(self.stopTimesLeft[busIndex].startIndex, offsetBy: 2)
                                let busHour = self.stopTimesLeft[busIndex].substring(to: startIndex)
                                let convertBusHoursToInt = Int(busHour)
                                let remainingHours = (convertBusHoursToInt! * 60 - hour * 60)
                                
                                let minutesIndex = self.stopTimesLeft[busIndex].index(self.stopTimesLeft[busIndex].startIndex, offsetBy: 3)
                                let busMinutes = self.stopTimesLeft[busIndex].substring(from: minutesIndex)
                                let convertBusMinutesToInt = Int(busMinutes)
                                let remainingMinutes = (remainingHours + convertBusMinutesToInt! - minutes)
                                
                                if remainingMinutes < 0 {
                                    self.stopTimesLeft[busIndex] = "Late"
                                } else {
                                    self.stopTimesLeft[busIndex] = "On time"
                                }

                            }
                            
                            self.check = 1
                            self.pinMap()
                            
                        }

                    } catch let error as NSError {
                        print(error)
                    }
                }
                
            }).resume()
        }
    }
    
    func pinMap() {
        for index in 0...stopNames.count-1 {
            
            let newPins = BusStop(title: stopNames[index],
                                   direction: "Timetabled bus time: " + stopTimes[index] /*+ " - Timetable status: " + stopTimesLeft[index]*/,
                                   discipline: "Bus Stop",
                                   coordinate: CLLocationCoordinate2D(latitude: stopLat[index], longitude: stopLong[index]))
            mapView.addAnnotation(newPins)
        }
        //Set middle pin as the one to zoom in on and call zoom function
        let middleInt = stopNames.count / 2
        let initialLocation = CLLocation(latitude: stopLat[middleInt], longitude: stopLong[middleInt])
        centerMapOnLocation(location: initialLocation)
    }
    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,
                                                                  regionRadius * 8.0, regionRadius * 8.0)
        mapView.setRegion(coordinateRegion, animated: true)
    }
}
