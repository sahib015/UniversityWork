//
//  BusStopViewControllerTests.swift
//  BuzAppTests
//
//  Created by Sahib Jabbal on 08/12/2017.
//  Copyright © 2017 University of Kent. All rights reserved.
//

import XCTest
@testable import BuzApp

var busStopViewControllerSessionUnderTest: URLSession!
class BusStopViewControllerTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        busStopViewControllerSessionUnderTest = URLSession(configuration: URLSessionConfiguration.default)
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        busStopViewControllerSessionUnderTest = nil
        super.tearDown()
    }
    
    func testGetStops(){
        // set bus stop atcocode for Keynes college stop A
        let limit = 5 // setting a limit
        let busStopAtcoCode = "2400A050300A"
        // the url to get the bus stop
        let getBusStopUrl = URL(string: "https://transportapi.com/v3/uk/bus/stop/\(busStopAtcoCode)/live.json?app_id=a8fbdc15&app_key=b3d5f933e236d4c2572657618ba78394&group=no&limit=\(limit)&nextbuses=yes")
        
        // what to expect when successful
        let successful = expectation(description: "Status code: 200")
        
        // when
        let dataTask = busStopViewControllerSessionUnderTest.dataTask(with: getBusStopUrl!) { data, response, error in
            // then
            if let error = error {
                XCTFail("Error: \(error.localizedDescription)")
                return
            } else if let statusCode = (response as? HTTPURLResponse)?.statusCode {
                if statusCode == 200 {
                    // 2
                    successful.fulfill()
                } else {
                    XCTFail("Status code: \(statusCode)")
                }
            }
        }
        dataTask.resume()
        waitForExpectations(timeout: 15, handler: nil)
    }
    
}
