//
//  FeedbackViewController.swift
//  BuzApp
//
//  Created by James McIntyre on 27/01/2017.
//  Copyright © 2017 University of Kent. All rights reserved.
//

import Foundation
import UIKit
import MessageUI

class FeedbackViewController: UIViewController, MFMailComposeViewControllerDelegate, UITextViewDelegate {

    @IBOutlet weak var messageBody: UITextView!
    @IBOutlet var srcScrollView: UIScrollView!
    let kentColor = UIColor(red: 9/255, green: 53/255, blue: 90/255, alpha: 1)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.barTintColor = kentColor
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName:UIColor.white]
        self.navigationController?.navigationBar.tintColor = UIColor.white

        self.SendFeedback(Any.self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func SendFeedback(_ sender: Any) {
        //Setting mail client variables
        let buzAppTeam = ["buzappfeedback123@gmail.com"]
        let subject = "Feedback for BuzApp iOS team"
        let message = "Hi BuzApp team,"
        
        let MailController: MFMailComposeViewController = MFMailComposeViewController()
        //Setting mail controller to take variables
        MailController.mailComposeDelegate = self
        MailController.setToRecipients(buzAppTeam)
        MailController.setSubject(subject)
        MailController.setMessageBody(message, isHTML: false)
        
        //Open mail client
        self.present(MailController, animated: true, completion: nil)
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        //Error handling and closing email client when done
        switch result.rawValue {
        case MFMailComposeResult.cancelled.rawValue:
            self.dismiss(animated: true, completion: nil)
        case MFMailComposeResult.saved.rawValue:
            self.dismiss(animated: true, completion: nil)
        case MFMailComposeResult.sent.rawValue:
            self.dismiss(animated: true, completion: nil)
        case MFMailComposeResult.failed.rawValue:
            self.dismiss(animated: true, completion: {
                let sendError = UIAlertController .init(title: "Warning!", message: "The message failed to send", preferredStyle: UIAlertControllerStyle.alert)
                sendError.addAction(UIAlertAction(title: "Warning!", style: UIAlertActionStyle.default, handler: nil))
                self.dismiss(animated: true, completion: nil)
            })
        default:
            break
        }
    
        self.dismiss(animated: true, completion: nil)
    }
    
}
