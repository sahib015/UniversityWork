//
//  FirstViewController.swift
//  BuzApp
//
//  Created by James McIntyre on 20/10/2016.
//  Refactored by Sahib Jabbal and Marc Jean-Pierre on 01/11/2017.
//  Copyright © 2016 University of Kent. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class FirstViewController: UIViewController {
    let kentColor = UIColor(red: 9/255, green: 53/255, blue: 90/255, alpha: 1)
    @IBOutlet weak var test: UILabel!// label to test the segment control if working... to be removed once tab view created
    @IBOutlet weak var segmentedControl: UISegmentedControl! // segment control for the nearest, favourite and recents tab

    @IBOutlet weak var nearestView: UIView!
    @IBOutlet weak var favouritesView: UIView!
    @IBOutlet weak var recentsView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
       
        self.navigationController?.navigationBar.barTintColor = kentColor
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName:UIColor.white]
        self.navigationController?.navigationBar.tintColor = UIColor.white
        
        UIView.animate(withDuration: 0.5, animations: {
            
            self.nearestView.alpha = 1.0
            self.favouritesView.alpha = 0.0
            self.recentsView.alpha = 0.0
        })
       
    }
    
    @IBAction func TabIndexChange(_ sender: UISegmentedControl) {
        
        switch segmentedControl.selectedSegmentIndex
        {
        case 0:
            //load nearest view
            UIView.animate(withDuration: 0.5, animations: {
                
                self.nearestView.alpha = 1.0
                self.favouritesView.alpha = 0.0
                self.recentsView.alpha = 0.0
            })
            
        case 1:
            //load favourites view
            UIView.animate(withDuration: 0.5, animations: {
                
                self.nearestView.alpha = 0.0
                self.favouritesView.alpha = 1.0
                self.recentsView.alpha = 0.0
            })
        case 2:
            UIView.animate(withDuration: 0.5, animations: {
                
                self.nearestView.alpha = 0.0
                self.favouritesView.alpha = 0.0
                self.recentsView.alpha = 1.0
            })
        default:
            break;
        }
    }
    
    

  
    
}
