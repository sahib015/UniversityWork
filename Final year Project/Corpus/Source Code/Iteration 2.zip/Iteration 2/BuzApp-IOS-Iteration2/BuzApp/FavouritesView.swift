//
//  FavouritesView.swift
//  BuzApp
//
//  Created by Sahib Jabbal on 31/10/2017.
//  Copyright © 2017 University of Kent. All rights reserved.
//

import UIKit

class FavouritesView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
