//
//  BusTableViewCell.swift
//  BuzApp
//
//  Created by Admin on 02/11/2016.
//  Copyright © 2016 University of Kent. All rights reserved.
//

import UIKit

class BusTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
