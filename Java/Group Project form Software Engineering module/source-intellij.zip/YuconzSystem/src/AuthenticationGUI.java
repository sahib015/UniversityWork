import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

/**
* gui class for the authentication process,
* sets up and display the gui and handles user input to provide
 * input to controller and return the output in suitable forms.
* Created by Group 29D on 16/02/2017
*/
class AuthenticationGUI extends JFrame{
    private JComboBox<String> accessRightsBox;
    private JTextField userNameField;
    private  JPasswordField pWordField;
    private AuthenticationController ac;
    public User userSession;
    private JFrame frame;
    private JPanel mainPanel;
    private JPanel buttonPanel;
    private GridBagConstraints constraints;
    /**
     * Constructor for GUI
     */
    AuthenticationGUI(){
        frame = new JFrame("Yuconz - Login");
        mainPanel = new JPanel(new GridBagLayout());
        buttonPanel = new JPanel(new GridBagLayout());
        constraints = new GridBagConstraints();
        ac = new AuthenticationController();
        setUp();
    }

    /**
     * Creates the gui window and it's content with use of other methods
     * once it is ready it makes the gui visible to the user.
     */
    private void setUp(){

        makeMenu();
        Container contentArea = frame.getContentPane();
        contentArea.setLayout(new BorderLayout());
        populateMainPanel();
        populateButtonPanel();
        contentArea.add(mainPanel,BorderLayout.CENTER);
        contentArea.add(buttonPanel,BorderLayout.SOUTH);

        frame.pack();
        frame.setMinimumSize(new Dimension(300,200));
        frame.setLocationRelativeTo(null);//setting frame to the center of the screen
        frame.setVisible(true);
        JOptionPane.showMessageDialog(frame, "users for demo all have the  password: password \n and the usernames are emp1, hre1, dir1, rev1 \n for employee, hremployee, director and reviewer respectivly" ,"About", JOptionPane.INFORMATION_MESSAGE);
    }

    private void populateMainPanel() {
        constraints.fill = GridBagConstraints.HORIZONTAL;

        //username field to panel
        userNameField = new JTextField();
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.insets = new Insets(3,3,3,3);
        mainPanel.add(new JLabel("Username: "), constraints);
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        mainPanel.add(userNameField, constraints);

        //adding options to the combobox for the user to select the access right
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        mainPanel.add(new JLabel("Login as: "), constraints);
        accessRightsBox = new JComboBox<>();
        fillAccessRightValues();
        constraints.gridx = 1;
        constraints.gridy = 1;
        constraints.gridwidth = 2;
        mainPanel.add(accessRightsBox, constraints);

        //password field to panel
        pWordField = new JPasswordField();
        constraints.gridx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        mainPanel.add(new JLabel("Password: "), constraints);
        constraints.gridx = 1;
        constraints.gridy = 2;
        constraints.gridwidth = 2;
        mainPanel.add(pWordField, constraints);
        mainPanel.setBorder(new EmptyBorder(0,10,0,0));
    }

    private void populateButtonPanel(){
        JButton loginButton = new JButton("Login");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        buttonPanel.add(loginButton,constraints);
        JButton cancelButton = new JButton("Cancel");
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        buttonPanel.add(cancelButton,constraints);
        buttonPanel.setBorder(new EmptyBorder(0,0,10,0));

        loginButton.addActionListener((ActionEvent e) -> {
            //gets the input values from the gui to be passed to the controller for checking
            String user = userNameField.getText();
            String pass = new String(pWordField.getPassword());
            int accessRightValue =  accessRightsBox.getSelectedIndex();
            if(ac.login(user,pass,accessRightValue)){
                userSession = new User(user,accessRightValue,ac.getStaffID(user)); //creates a user object to be used in other areas
               //get value of access level
                //userSession.getAccessLevel();
                frame.dispose();
                JOptionPane.showMessageDialog(null,"Welcome " + user + " to Yuconz Management System");
                //redirects to createPD (will change it with the correct access right
                new PersonalDetailsMainGUI(userSession);

            }else{
                JOptionPane.showMessageDialog(null,"Invalid username or password, \nplease try again.","Yuconz - Login",JOptionPane.ERROR_MESSAGE);
            }
        });

        cancelButton.addActionListener(e ->
                System.exit(0));
    }

    /**
     * Creates the menuBar for the gui and allocates it to the gui frame.
     */
    private void makeMenu()
    {
        //creates and populates a menuBar with a file and help which contain quit and about respectively
        JMenuBar menuBar = new JMenuBar();
        JMenu menu;
        JMenuItem item;

        frame.setJMenuBar(menuBar);
        menu = new JMenu("File");

        item = new JMenuItem("Quit");
        item.addActionListener(e ->
                System.exit(0));
        menu.add(item);
        menuBar.add(menu);

        menu = new JMenu("Help");

        item = new JMenuItem("About");
        item.addActionListener(e ->
                JOptionPane.showMessageDialog(frame, "users for demo all have the  password: password \n and the usernames are emp1, hre1, dir1, rev1 \n for employee, hremployee, director and reviewer respectivly" ,"About", JOptionPane.INFORMATION_MESSAGE));
        menu.add(item);

        menuBar.add(menu);
    }
    /**
     * Gets values from the controller to populate the combobox with.
     */
    private void fillAccessRightValues(){
        accessRightsBox.addItem("Select login level...");
        ArrayList<String> values = ac.getARBoxValues();
        if(values==null){
            throw new NullPointerException();
        }else {
            for (String x : values) {
                accessRightsBox.addItem(x);
            }
        }
    }


}
