import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * test class for the Authentication server
 * Created by Group 29D on 1/03/2017
 */
public class AuthenticationServerTest {
    private AuthenticationServer authenticationServer;
    @Before
    public void setUp() throws Exception {
        authenticationServer = new AuthenticationServer();
    }

    @After
    public void tearDown() throws Exception {

    }

    @org.junit.Test
    public void connectToDatabase() throws Exception {
        //test that connecting to the database works.
        assert(authenticationServer.dbConnect() != null);
    }

    @org.junit.Test
    public void userLoginWithCorrectRights() throws Exception {
        //test an employee login in with correct access right of employee selected
        assert (authenticationServer.authenticateLogin("emp1","password",1));
    }

    @org.junit.Test
    public void userLoginWithWrongPassword() throws Exception {
        //test an employee login in with correct access right of employee selected
        assert (!authenticationServer.authenticateLogin("emp1","notThePassword",1));
    }

    @org.junit.Test
    public void userLoginWithWrongName() throws Exception {
        //test an employee login in with correct access right of employee selected
        assert (!authenticationServer.authenticateLogin("emp01","password",1));
    }

    @org.junit.Test
    public void userLoginWithElevatedRights() throws Exception {
        //test an employee login in with incorrect access right of director selected
        assert (!authenticationServer.authenticateLogin("emp1","password",4));
    }
    @org.junit.Test
    public void userLoginWithLoweredRights() throws Exception {
        //test a director login in with lowered but correct access right of employee selected
        assert (authenticationServer.authenticateLogin("dir1","password",1));
    }

    @Test
    public void getARBoxValues() throws Exception {
        assert (authenticationServer.getARBoxValues() != null);
    }

}