import com.toedter.calendar.JDateChooser;
import datastructures.Employee;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.Date;

/**
 * gui for crating Personal Details
 * Created by Group 29D on 02-Mar-17.
 */
class PersonalDetailsAmendGUI extends JFrame {
    private JFrame frame;
    //TextFields
    private JTextField txtStaffNo = new JTextField();
    private JTextField txtSurname = new JTextField();
    private JTextField txtName = new JTextField();
    //private JTextField txtDob= new JTextField();//to change to date picker
    private JDateChooser txtDob = new JDateChooser();
    private JTextField txtAddress = new JTextField();
    private JTextField txtTown = new JTextField();
    private JTextField txtCounty = new JTextField();
    private JTextField txtPostcode = new JTextField();
    private JTextField txtTelNo = new JTextField();
    private JTextField txtMobileNo = new JTextField();
    private JTextField txtEmergencyContact = new JTextField();
    private JTextField txtEmergencyContactNo = new JTextField();
    //buttons
    private GridBagConstraints constraints;
    private JPanel buttonPanel = new JPanel(new GridBagLayout());
    private JPanel mainPanel = new JPanel(new GridBagLayout());
    //controller
    private PersonalDetailsController personalDetailsController;
    private User user;

    /**
     * constructor
     * @param staffId the staff ID of the employee personal details to amend
     */
    PersonalDetailsAmendGUI(String staffId) {
        personalDetailsController = new PersonalDetailsController();
        constraints = new GridBagConstraints();
        setup(staffId);
    }

    /**
     * Creates the gui window and it's content with use of other methods
     * once it is ready it makes the gui visible to the user.
     * @param staffId the staff ID of the employee personal details to amend
     */
    private void setup(String staffId) {
        frame = new JFrame("Yuconz - Personal Details");
        makeMenu(frame);
        Container contentArea = frame.getContentPane();

        //Get Data on employee with employee id from HRDatabase
        Employee employee = personalDetailsController.getIndividualPersonalDetails(staffId);;
        //Store in variable
        //setText of each field individually
        //Make the query of this UPDATE not INSERT
        //Done

        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(3, 3, 3, 3);
        //staff no to panel
        constraints.gridx = 0;
        constraints.weightx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        mainPanel.add(new JLabel("StaffNo:"), constraints);
        constraints.gridwidth = 1;
        constraints.weightx = 0.5;
        constraints.gridx = 1;
        txtStaffNo.setText(employee.getStaffId());
        mainPanel.add(txtStaffNo, constraints);
        contentArea.setLayout(new BorderLayout());

        //surname to panel
        constraints.gridx = 0;
        constraints.weightx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        mainPanel.add(new JLabel("Surname:"), constraints);
        constraints.gridwidth = 1;
        constraints.weightx = 0.5;
        constraints.gridx = 1;
        txtSurname.setText(employee.getSurname());
        mainPanel.add(txtSurname, constraints);

        //name to panel
        constraints.gridx = 0;
        constraints.weightx = 0;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        mainPanel.add(new JLabel("Name:"), constraints);
        constraints.gridwidth = 1;
        constraints.weightx = 0.5;
        constraints.gridx = 1;
        txtName.setText(employee.getName());
        mainPanel.add(txtName, constraints);

        //DOB to panel
        constraints.gridx = 0;
        constraints.weightx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 1;
        mainPanel.add(new JLabel("Date of Birth:"), constraints);
        constraints.gridwidth = 1;
        constraints.weightx = 0.5;
        constraints.gridx = 1;
        txtDob.setDate(employee.getDob());
        mainPanel.add(txtDob, constraints);

        //Address to panel
        constraints.gridx = 0;
        constraints.weightx = 0;
        constraints.gridy = 4;
        constraints.gridwidth = 1;
        mainPanel.add(new JLabel("Address:"), constraints);
        constraints.gridwidth = 1;
        constraints.weightx = 0.5;
        constraints.gridx = 1;
        txtAddress.setPreferredSize(new Dimension(450, 90));
        txtAddress.setEditable(true);
        txtAddress.setText(employee.getAddress());
        mainPanel.add(txtAddress, constraints);

        //town to panel
        constraints.gridx = 0;
        constraints.weightx = 0;
        constraints.gridy = 5;
        constraints.gridwidth = 1;
        mainPanel.add(new JLabel("Town:"), constraints);
        constraints.gridwidth = 1;
        constraints.weightx = 0.5;
        constraints.gridx = 1;
        txtTown.setText(employee.getTown());
        mainPanel.add(txtTown, constraints);

        //county to panel
        constraints.gridx = 0;
        constraints.weightx = 0;
        constraints.gridy = 6;
        constraints.gridwidth = 1;
        mainPanel.add(new JLabel("County:"), constraints);
        constraints.gridwidth = 1;
        constraints.weightx = 0.5;
        constraints.gridx = 1;
        txtCounty.setText(employee.getCounty());
        mainPanel.add(txtCounty, constraints);

        //postcode to panel
        constraints.gridx = 0;
        constraints.weightx = 0;
        constraints.gridy = 7;
        constraints.gridwidth = 1;
        mainPanel.add(new JLabel("Postcode:"), constraints);
        constraints.gridwidth = 1;
        constraints.weightx = 0.5;
        constraints.gridx = 1;
        txtPostcode.setText(employee.getPostcode());
        mainPanel.add(txtPostcode, constraints);

        //tel no to panel
        constraints.gridx = 0;
        constraints.weightx = 0;
        constraints.gridy = 8;
        constraints.gridwidth = 1;
        mainPanel.add(new JLabel("Telephone Number:"), constraints);
        constraints.gridwidth = 1;
        constraints.weightx = 0.5;
        constraints.gridx = 1;
        txtTelNo.setText(employee.getTelNo());
        mainPanel.add(txtTelNo, constraints);

        //mobile no to panel
        constraints.gridx = 0;
        constraints.weightx = 0;
        constraints.gridy = 9;
        constraints.gridwidth = 1;
        mainPanel.add(new JLabel("Mobile Number:"), constraints);
        constraints.gridwidth = 1;
        constraints.weightx = 0.5;
        constraints.gridx = 1;
        txtMobileNo.setText(employee.getMobileNo());
        mainPanel.add(txtMobileNo, constraints);

        //emergency contact to panel
        constraints.gridx = 0;
        constraints.weightx = 0;
        constraints.gridy = 10;
        constraints.gridwidth = 1;
        mainPanel.add(new JLabel("Emergency Contact Name:"), constraints);
        constraints.gridwidth = 1;
        constraints.weightx = 0.5;
        constraints.gridx = 1;
        txtEmergencyContact.setText(employee.getEmergencyContact());
        mainPanel.add(txtEmergencyContact, constraints);

        //staff no to panel
        constraints.gridx = 0;
        constraints.weightx = 0;
        constraints.gridy = 11;
        constraints.gridwidth = 1;
        mainPanel.add(new JLabel("Emergency Contact Number:"), constraints);
        constraints.gridwidth = 1;
        constraints.weightx = 0.5;
        constraints.gridx = 1;
        txtEmergencyContactNo.setText(employee.getEmergencyContactNo());
        mainPanel.add(txtEmergencyContactNo, constraints);

        // buttons to panel
        populateButtonPanel();

        contentArea.add(mainPanel, BorderLayout.CENTER);
        contentArea.add(buttonPanel, BorderLayout.SOUTH);
        frame.pack();
        frame.setMinimumSize(new Dimension(550, 200));
        frame.setLocationRelativeTo(null);//setting frame to the center of the screen
        frame.setVisible(true);
    }

    private void populateButtonPanel() {
        JButton btnSave = new JButton("Save");
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.gridwidth = 1;
        constraints.weightx = 0;
        buttonPanel.add(btnSave, constraints);
        JButton btnCancel = new JButton("Cancel");
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.weightx = 0;
        constraints.gridwidth = 1;
        buttonPanel.add(btnCancel, constraints);
        buttonPanel.setBorder(new EmptyBorder(0, 0, 10, 0));

        btnCancel.addActionListener(e -> {

            frame.dispose();
            //redirects to createPD (will change it with the correct access right
            new PersonalDetailsMainGUI(user);
        });

        btnSave.addActionListener((ActionEvent e) -> {
            //gets the input values from the gui to be passed to the controller for checking to add to the database
            int staffId = Integer.parseInt(txtStaffNo.getText());
            String surname = txtSurname.getText();
            String name = txtName.getText();
            Date dob = txtDob.getDate();
            String address = txtAddress.getText();
            String town = txtTown.getText();
            String county = txtCounty.getText();
            String postCode = txtPostcode.getText();
            String telNo = txtTelNo.getText();
            String mobileNo = txtMobileNo.getText();
            String emergencyContact = txtEmergencyContact.getText();
            String emergencyContactNo = txtEmergencyContactNo.getText();

            personalDetailsController.amendPersonalDetails(staffId,
                    surname,
                    name,
                    dob,
                    address,
                    town,
                    county,
                    postCode,
                    telNo,
                    mobileNo,
                    emergencyContact,
                    emergencyContactNo
            );

            JOptionPane.showMessageDialog(null, name + " " + surname + " successfully saved");

            frame.dispose();
            //redirects to createPD (will change it with the correct access right
            new PersonalDetailsMainGUI(user);

        });
    }

    /**
     * Creates the menuBar for the gui and allocates it to the gui frame.
     *
     * @param frame the gui window to which the menu is to be added to.
     */
    private void makeMenu(JFrame frame) {
        //creates and populates a menuBar with a file and help which contain quit and about respectively
        JMenuBar menuBar = new JMenuBar();
        JMenu menu;
        JMenuItem item;

        frame.setJMenuBar(menuBar);
        menu = new JMenu("File");

        item = new JMenuItem("Quit");
        item.addActionListener(e ->
                System.exit(0));
        menu.add(item);
        menuBar.add(menu);

        menu = new JMenu("Help");

        item = new JMenuItem("About");
        item.addActionListener(e ->
                JOptionPane.showMessageDialog(frame, "users for demo all have the  password: password \n and the usernames are emp1, hre1, dir1, rev1 \n for employee, hremployee, director and reviewer respectivly", "About", JOptionPane.INFORMATION_MESSAGE));
        menu.add(item);
        menuBar.add(menu);

        item = new JMenuItem("Logout");
        item.addActionListener(e -> {
            dispose();
            new AuthenticationGUI();
        });
    }
}
