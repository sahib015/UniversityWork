import datastructures.Employee;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 * handles all the database queries that is used by the personalDetailsController and ReviewerController classes.
 * Created by Group 29D on 02-Mar-17.
 */
public class HRDatabase {
    private int count = 0;

    /**
     * Connects to the HRDatabase
     *
     * @return the connection if successful or null if not.
     */
    private Connection dbConnect() {
        try {
            Class.forName("org.sqlite.JDBC");
            return DriverManager.getConnection("jdbc:sqlite:HRDatabase.sqlite");
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * adds the personal details of an employee
     *
     * @param staffID-            value of the staffID (6 digit value)
     * @param surname-            value of surname of employee
     * @param name                value of name of employee
     * @param dob-                value of dob of employee
     * @param address-            value of address of employee
     * @param town-               value of town of employee
     * @param county-             value of county of employee
     * @param postCode-           value of postCode of employee
     * @param telNo-              value of telNo of employee
     * @param mobileNo-           value of mobileNo of employee
     * @param emergencyContact-   value of emergencyContact of employee
     * @param emergencyContactNo- value of emergencyContactNo of employee
     */
    void addRecord(int staffID, String surname, String name, java.util.Date dob, String address, String town, String county,
                   String postCode, String telNo, String mobileNo, String emergencyContact, String emergencyContactNo) {

        try {
            Connection connection = this.dbConnect();
            String insertSql = "insert into personalDetails(staffID,surname,name,dob,address,town,county,postcode,telNo," +
                    "mobileNo,emergencyContact,emergencyContactNo) values(?,?,?,?,?,?,?,?,?,?,?,?)";
            assert connection != null;
            PreparedStatement ps = connection.prepareStatement(insertSql);
            ps.setInt(1, staffID);
            ps.setString(2, surname);
            ps.setString(3, name);
            ps.setDate(4, (new java.sql.Date(dob.getTime())));
            ps.setString(5, address);
            ps.setString(6, town);
            ps.setString(7, county);
            ps.setString(8, postCode);
            ps.setString(9, telNo);
            ps.setString(10, mobileNo);
            ps.setString(11, emergencyContact);
            ps.setString(12, emergencyContactNo);

            //adding the values to the database
            ps.executeUpdate();


        } catch (Exception e) {
            System.out.println(e.getMessage() + " HRDatabase");
        }
    }

    /**
     * adds the personal details of an employee
     *
     * @param staffID-            value of the staffID (6 digit value)
     * @param surname-            value of surname of employee
     * @param name                value of name of employee
     * @param dob-                value of dob of employee
     * @param address-            value of address of employee
     * @param town-               value of town of employee
     * @param county-             value of county of employee
     * @param postCode-           value of postCode of employee
     * @param telNo-              value of telNo of employee
     * @param mobileNo-           value of mobileNo of employee
     * @param emergencyContact-   value of emergencyContact of employee
     * @param emergencyContactNo- value of emergencyContactNo of employee
     */
    void updateRecord(int staffID, String surname, String name, java.util.Date dob, String address, String town, String county,
                   String postCode, String telNo, String mobileNo, String emergencyContact, String emergencyContactNo) {

        try {
            Connection connection = this.dbConnect();
            String insertSql = "update personalDetails set staffID=?,surname=?,name=?,dob=?,address=?,town=?," +
                    "county=?,postcode=?,telNo=?,mobileNo=?,emergencyContact=?,emergencyContactNo=? where staffID=?";
            assert connection != null;
            PreparedStatement ps = connection.prepareStatement(insertSql);
            ps.setInt(1, staffID);
            ps.setString(2, surname);
            ps.setString(3, name);
            ps.setDate(4, (new java.sql.Date(dob.getTime())));
            ps.setString(5, address);
            ps.setString(6, town);
            ps.setString(7, county);
            ps.setString(8, postCode);
            ps.setString(9, telNo);
            ps.setString(10, mobileNo);
            ps.setString(11, emergencyContact);
            ps.setString(12, emergencyContactNo);
            ps.setInt(13, staffID);

            //adding the values to the database
            ps.executeUpdate();


        } catch (Exception e) {
            System.out.println(e.getMessage() + " HRDatabase");
        }
    }

    /**
     *
     * @return employeeList a list of employees
     */
    ArrayList<Employee> getPersonalDetails() {
        ArrayList<Employee> employeeList = new ArrayList<>();
        Connection connection = this.dbConnect();
        String sql = "select staffID, surname, name from personalDetails";
        assert connection != null;
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Employee employee = new Employee();
                employee.setStaffId(rs.getString("staffID"));
                employee.setSurname(rs.getString("surname"));
                employee.setName(rs.getString("name"));
                employeeList.add(employee);
                ++count;
            }
            rs.close();
            ps.close();
            return employeeList;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    /**
     * Get's an individual employee's personal details
     *
     * @param staffId an individual employee's staff ID
     * @return
     */
    Employee getIndividualPersonalDetails(String staffId) {
        Employee employee = new Employee();
        Connection connection = this.dbConnect();
        String sql = "select * from personalDetails where staffID=?";
        assert connection != null;
        PreparedStatement ps;
        try {
            ps = connection.prepareStatement(sql);
            ps.setString(1,staffId);
            ResultSet rs = ps.executeQuery();

            //Set employee details
            employee.setStaffId(rs.getString("staffID"));
            employee.setSurname(rs.getString("surname"));
            employee.setName(rs.getString("name"));

            //Just date formatting. Convert the sql date non-sense to a date format
            //suitable for the datepicker in the GUI
            java.util.Date date1 = rs.getTimestamp("dob");
            String stringDate = date1.toString();
            employee.setDob(date1);

            //Set rest of employee details
            employee.setAddress(rs.getString("address"));
            employee.setTown(rs.getString("town"));
            employee.setCounty(rs.getString("county"));
            employee.setPostcode(rs.getString("postcode"));
            employee.setTelNo(rs.getString("telNo"));
            employee.setMobileNo(rs.getString("mobileNo"));
            employee.setEmergencyContact(rs.getString("emergencyContact"));
            employee.setEmergencyContactNo(rs.getString("emergencyContactNo"));


/*
                Employee employee = new Employee();
                employee.setStaffId(rs.getString("staffID"));
                employee.setSurname(rs.getString("surname"));
                employee.setName(rs.getString("name"));
                employeeList.add(employee);*/
            rs.close();
            ps.close();
            return employee;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    public int getNoOfRecords() {
        return count;
    }
}
