import datastructures.Employee;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * Created by SSJ on 04-Mar-17.
 */
public class PersonalDetailsMainGUI {
    private JFrame frame = new JFrame("Yuconz - Personal Details Records");
    private JPanel mainPanel = new JPanel(new GridBagLayout());
    private GridBagConstraints constraints;
    private User user;

    private PersonalDetailsController personalDetailsController = new PersonalDetailsController();

    public PersonalDetailsMainGUI(User user) {
        constraints = new GridBagConstraints();
        this.user = user;
        setup();
    }

    private void setup() {
        makeMenu();
        Container contentArea = frame.getContentPane();
        ArrayList<Employee> values = personalDetailsController.getData();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(3, 3, 3, 3);
        int edv = 0; //these are used to move where labels and buttons are added during the foreach loop
        int bta = 0; //these are used to move where labels and buttons are added during the foreach loop
        int btr = 1; //these are used to move where labels and buttons are added during the foreach loop
        if (values == null) {
            throw new NullPointerException();
        } else {
            String employeeDetails;
            for (Employee x : values) {
                System.out.println(x.getName()); //for testing purposes
                int staffNo = Integer.parseInt(x.getStaffId());
                employeeDetails = "<html>Staff ID: " + x.getStaffId() + "<br>Name: " + x.getName() + " " + x.getSurname() + "</html>";
                constraints.gridx = 0;
                constraints.gridy = edv;
                constraints.gridwidth = 2;
                constraints.gridheight = 2;
                mainPanel.add(new JLabel(employeeDetails),constraints);
                JButton btnAmend = new JButton("Amend");
                JButton btnRead = new JButton("Read");
                btnAmend.setActionCommand(x.getStaffId());
                btnRead.setActionCommand(x.getStaffId());

                constraints.gridx = 2;
                constraints.gridwidth = 1;
                constraints.gridheight = 1;
                constraints.gridy = bta;
                mainPanel.add(btnAmend, constraints);

                constraints.gridx = 2;
                constraints.gridy = btr;
                mainPanel.add(btnRead, constraints);

                JButton btnCreate = new JButton("Create Record");

                if (user.getStaffID() == staffNo) {
                    btnRead.setEnabled(true);
                    btnAmend.setEnabled(true);
                }
                else if(user.getAccessLevel()==3){
                    btnCreate.setEnabled(true);
                    btnAmend.setEnabled(true);
                    btnRead.setEnabled(true);
                }
                else if(user.getAccessLevel()==4){
                    btnCreate.setEnabled(false);
                    btnAmend.setEnabled(true);
                    btnRead.setEnabled(true);
                } else {
                    btnCreate.setEnabled(false);
                    btnRead.setEnabled(false);
                    btnAmend.setEnabled(false);
                }

                edv= edv+2;
                bta=bta+2;
                btr=btr+2;
                btnAmend.addActionListener(e -> {
                    System.out.println(btnAmend.getActionCommand() + "amend"); //for testing purposes
                    frame.dispose();
                    new PersonalDetailsAmendGUI(btnAmend.getActionCommand());
                });

                btnRead.addActionListener(e -> {
                    System.out.println(btnRead.getActionCommand() + "read"); //for testing purposes
                    frame.dispose();
                    new PersonalDetailsReadGUI(btnAmend.getActionCommand());
                });

                btnCreate.addActionListener(e -> {
                    System.out.println(btnCreate.getActionCommand() + "create"); //for testing purposes
                    frame.dispose();
                    new PersonalDetailsCreateGUI(user);
                });

                contentArea.setLayout(new BorderLayout());
                contentArea.add(mainPanel, BorderLayout.NORTH);
                contentArea.add(btnCreate, BorderLayout.LINE_START);
            }

            frame.pack();
            frame.setMinimumSize(new Dimension(550, 200));
            frame.setLocationRelativeTo(null);//setting frame to the center of the screen
            frame.setVisible(true);
        }
    }
    private void makeMenu()
    {
        //creates and populates a menuBar with a file and help which contain quit and about respectively
        JMenuBar menuBar = new JMenuBar();
        JMenu menu;
        JMenuItem item;

        frame.setJMenuBar(menuBar);
        menu = new JMenu("File");

        item = new JMenuItem("Quit");
        item.addActionListener(e ->
                System.exit(0));
        menu.add(item);
        menuBar.add(menu);

        menu = new JMenu("Help");

        item = new JMenuItem("About");
        item.addActionListener(e ->
                JOptionPane.showMessageDialog(frame, "users for demo all have the  password: password \n and the usernames are emp1, hre1, dir1, rev1 \n for employee, hremployee, director and reviewer respectivly" ,"About", JOptionPane.INFORMATION_MESSAGE));
        menu.add(item);
        menuBar.add(menu);

        item = new JMenuItem("Logout");
        item.addActionListener(e -> {
            user = null;
            frame.dispose();
            new AuthenticationGUI();
        });
        menuBar.add(item);
    }

}
